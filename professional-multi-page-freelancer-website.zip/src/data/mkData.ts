export type PageId = 'home' | 'work' | 'services' | 'offers' | 'reviews' | 'studio';

export type FrontTextStyle = 'hybrid' | 'brutalist' | 'couture' | 'outlined';

export interface ProjectItem {
  id: string;
  index: string;
  title: string;
  subtitle: string;
  client: string;
  location: string;
  year: string;
  duration: string;
  category: 'Full-Stack' | 'UI/UX Architecture' | 'E-Commerce' | 'WebGL & Motion' | 'AI Systems';
  featured: boolean;
  accentColor: string;
  secondaryColor: string;
  metricBadge: string;
  metricDetail: string;
  summary: string;
  challenge: string;
  architecture: string;
  typographyNote: string;
  deliverables: string[];
  stack: string[];
  benchmarks: {
    label: string;
    before: string;
    after: string;
    improvement: string;
  }[];
  livePreviewStats: {
    lighthouse: number;
    fps: number;
    ttfb: string;
    uptime: string;
  };
  clientQuote: {
    text: string;
    author: string;
    role: string;
  };
}

export interface ServiceItem {
  id: string;
  code: string;
  title: string;
  editorialTag: string;
  shortDesc: string;
  detailedDesc: string;
  turnaround: string;
  startingAtUSD: number;
  deliverables: string[];
  technologies: string[];
  idealFor: string;
  outcomeMetric: string;
}

export interface OfferTier {
  id: string;
  code: string;
  name: string;
  tagline: string;
  badge?: string;
  highlighted?: boolean;
  sprintPriceUSD: number;
  retainerPriceUSD: number;
  durationLabel: string;
  capacityStatus: string;
  description: string;
  features: string[];
  guarantees: string[];
  ctaLabel: string;
}

export interface FlashOffer {
  id: string;
  code: string;
  title: string;
  subtitle: string;
  discountBadge: string;
  originalUSD: number;
  offerUSD: number;
  turnaround: string;
  slotsRemaining: number;
  description: string;
  includes: string[];
}

export interface ReviewItem {
  id: string;
  index: string;
  clientName: string;
  role: string;
  company: string;
  location: string;
  category: 'SaaS & AI' | 'Fintech' | 'E-Commerce' | 'Design Systems';
  rating: number;
  date: string;
  projectDelivered: string;
  verifiedImpact: string;
  headlineQuote: string;
  fullReview: string;
  budgetRange: string;
}

export const MK_PROFILE = {
  fullName: 'Moin Uddin Khan',
  brandAlias: 'Freelancer MK',
  monogram: 'MK // 26',
  role: 'Principal Creative Technologist & Full-Stack Product Architect',
  tagline: 'Crafting Uncommon Typography, Sub-Second Web Architecture & High-Yield Digital Products.',
  availability: '2 CLIENT SLOTS OPEN FOR MAY / JUNE',
  responseSLA: '< 3.5 Hours Average Response',
  experienceYears: '7+ Years',
  projectsShipped: '64+',
  clientRetention: '94%',
  valueCreated: '$48M+',
  email: 'moin@freelancermk.studio',
  handle: '@freelancermk',
  location: 'Global Remote // UTC+6 & UTC/EST Sync',
};

export const PROJECTS: ProjectItem[] = [
  {
    id: 'aetheria-quantum',
    index: '01',
    title: 'AETHERIA QUANTUM',
    subtitle: 'Institutional AI Liquidity & Orderbook Execution Terminal',
    client: 'Aetheria Labs AG',
    location: 'Zurich, Switzerland',
    year: '2025',
    duration: '6 Weeks',
    category: 'Full-Stack',
    featured: true,
    accentColor: '#E2FF32',
    secondaryColor: '#10B981',
    metricBadge: '+310% Execution Speed',
    metricDetail: '$42M Monthly Institutional Volume Routed',
    summary:
      'Engineered a zero-latency WebSocket trading cockpit and algorithmic liquidity visualizer capable of rendering 12,000 orderbook ticks per second at locked 60fps.',
    challenge:
      'Aetheria’s legacy React dashboard suffered from severe main-thread blocking during volatile market opens, causing 1.4-second UI freezes and institutional trader drop-off.',
    architecture:
      'Replaced standard DOM state updates with a WebWorker binary ring-buffer and Canvas-assisted virtualization layer, paired with a high-contrast Swiss monospace telemetry grid.',
    typographyNote:
      'Set in Syne 800 Extended headers paired with tabular Space Mono micro-numerals for zero horizontal jitter during sub-millisecond price ticks.',
    deliverables: [
      'Real-Time WebSocket Orderbook Engine',
      'Custom Design System (84 Dark-Mode Tokens)',
      'Multi-Wallet Institutional Custody Flow',
      'Automated End-to-End Playwright Test Suite',
    ],
    stack: ['Next.js 15', 'TypeScript', 'WebSockets', 'Tailwind CSS', 'WebWorkers', 'Rust/WASM'],
    benchmarks: [
      { label: 'Frame Time Under Load', before: '48.2 ms', after: '6.4 ms', improvement: '7.5x Faster' },
      { label: 'Time to Interactive (TTI)', before: '3.9 sec', after: '0.55 sec', improvement: '-86% Latency' },
      { label: 'Institutional Retention', before: '61%', after: '94%', improvement: '+33% Lift' },
    ],
    livePreviewStats: {
      lighthouse: 100,
      fps: 60,
      ttfb: '38ms',
      uptime: '99.99%',
    },
    clientQuote: {
      text: 'Moin (Freelancer MK) architected a frontend that feels like a defense-grade cockpit. Our institutional desk volume tripled within 45 days of deployment.',
      author: 'Lukas Vance',
      role: 'CTO, Aetheria Labs Zurich',
    },
  },
  {
    id: 'kinetix-atelier',
    index: '02',
    title: 'KINETIX ATELIER',
    subtitle: 'Spatial Luxury Commerce & Kinetic Editorial Flagship',
    client: 'Kinetix Paris / Tokyo',
    location: 'Paris, France',
    year: '2025',
    duration: '5 Weeks',
    category: 'E-Commerce',
    featured: true,
    accentColor: '#FF4D2D',
    secondaryColor: '#E2FF32',
    metricBadge: '+64% Checkout Conversion',
    metricDetail: '2.8x Average Order Value Increase',
    summary:
      'Bespoke headless flagship store merging brutalist oversized editorial typography with instant GPU cloth-shader garment inspection and 1-click slide-over checkout.',
    challenge:
      'Standard luxury e-commerce templates diluted Kinetix’s avant-garde brand identity while suffering from slow 4-second page reloads between lookbook chapters.',
    architecture:
      'Built an optimistic prefetching headless Shopify Hydrogen architecture with custom WebGL displacement transitions and persistent cart state.',
    typographyNote:
      'Combined monumental Instrument Serif italics with razor-sharp brutalist grid indices, turning every product drop into an interactive fashion monograph.',
    deliverables: [
      'Headless Storefront Architecture',
      'Interactive Lookbook Scrollytelling Engine',
      'Slide-Over Express Stripe/Apple Pay Checkout',
      'Multi-Currency & Localization Edge Router',
    ],
    stack: ['React 19', 'Shopify Storefront API', 'GLSL Shaders', 'Framer Motion', 'Tailwind CSS'],
    benchmarks: [
      { label: 'Checkout Completion Rate', before: '1.9%', after: '3.12%', improvement: '+64% Lift' },
      { label: 'Route Transition Speed', before: '2.4 sec', after: '0.18 sec', improvement: 'Instant' },
      { label: 'Mobile Revenue Share', before: '42%', after: '71%', improvement: '+69% Growth' },
    ],
    livePreviewStats: {
      lighthouse: 99,
      fps: 60,
      ttfb: '44ms',
      uptime: '100%',
    },
    clientQuote: {
      text: 'MK possesses that rare duality: the eye of an editorial art director and the rigor of a systems engineer. Our Paris drop sold out in 19 minutes.',
      author: 'Céline Moreau',
      role: 'Creative Director, Kinetix Atelier',
    },
  },
  {
    id: 'veridian-cloud-os',
    index: '03',
    title: 'VERIDIAN CLOUD OS',
    subtitle: 'Distributed Edge Compute Control Plane & Tokenized Design System',
    client: 'Veridian Infrastructure Inc.',
    location: 'San Francisco, USA',
    year: '2024',
    duration: '8 Weeks',
    category: 'UI/UX Architecture',
    featured: true,
    accentColor: '#38BDF8',
    secondaryColor: '#E2FF32',
    metricBadge: '48% Faster Dev Velocity',
    metricDetail: '140+ Accessible Primitives Shipped',
    summary:
      'Unified four fragmented developer consoles into a single keyboard-first cloud operating system with a live global node topology map and command palette.',
    challenge:
      'Four engineering squads were shipping inconsistent modals, forms, and telemetry charts, resulting in a bloated 2.2MB JS bundle and steep onboarding friction.',
    architecture:
      'Designed and coded a strict zero-runtime-overhead component library in TypeScript & Radix primitives with automated Figma-to-GitHub token synchronization.',
    typographyNote:
      'Engineered a high-density typographic hierarchy that allows DevOps engineers to scan 40+ cluster metrics on a 13-inch display without visual fatigue.',
    deliverables: [
      '140+ Production React/TypeScript Components',
      'Interactive Global Edge Topology Visualizer',
      'Cmd+K Universal Action Palette',
      'Interactive Storybook & Documentation Portal',
    ],
    stack: ['TypeScript', 'React', 'Radix UI', 'Tailwind v4', 'D3.js', 'Storybook'],
    benchmarks: [
      { label: 'JS Bundle Payload', before: '2,180 KB', after: '340 KB', improvement: '-84% Size' },
      { label: 'Feature Ship Cycle', before: '14 Days', after: '7.2 Days', improvement: '48% Faster' },
      { label: 'Accessibility Score', before: '74 / 100', after: '100 / 100', improvement: 'WCAG AAA' },
    ],
    livePreviewStats: {
      lighthouse: 100,
      fps: 60,
      ttfb: '31ms',
      uptime: '99.99%',
    },
    clientQuote: {
      text: 'Working with Freelancer MK saved us from hiring three full-time frontend engineers. The design system he delivered is now the backbone of our Series B product.',
      author: 'Marcus Chen',
      role: 'VP of Engineering, Veridian Cloud',
    },
  },
  {
    id: 'chronos-neural',
    index: '04',
    title: 'CHRONOS NEURAL',
    subtitle: 'Autonomous Multi-Agent Workflow Canvas & Prompt IDE',
    client: 'Chronos AI Labs',
    location: 'London, UK',
    year: '2025',
    duration: '4 Weeks',
    category: 'AI Systems',
    featured: true,
    accentColor: '#A855F7',
    secondaryColor: '#E2FF32',
    metricBadge: '18,400+ Active Teams',
    metricDetail: '4.9/5 ProductHunt #1 Launch',
    summary:
      'Architected an infinite spatial node canvas for chaining LLM agents, real-time token streaming inspectors, and deterministic cost-per-run telemetry.',
    challenge:
      'AI builders struggled to debug multi-step agent handoffs in linear chat interfaces, needing an intuitive visual graph with live streaming inspection.',
    architecture:
      'Built a custom viewport-culled spatial node editor with Server-Sent Events (SSE) token streaming and instant branch forking.',
    typographyNote:
      'Contrast between sculptural Syne display headers in the workspace chrome and ultra-clean monospace prompt diffing blocks.',
    deliverables: [
      'Infinite Spatial Node Graph Editor',
      'Real-Time Token & Cost Telemetry Streamer',
      'One-Click Prompt Diff & Version Time-Machine',
      'High-Conversion Product Launch Website',
    ],
    stack: ['Next.js', 'TypeScript', 'Canvas API', 'OpenAI / Anthropic SDK', 'Zustand'],
    benchmarks: [
      { label: 'Landing Page Signups', before: '2.4%', after: '8.7%', improvement: '3.6x Conversion' },
      { label: 'Canvas Node Capacity', before: '50 Nodes', after: '1,500+ Nodes', improvement: '30x Scale' },
      { label: 'User Onboarding Time', before: '18 Mins', after: '2.5 Mins', improvement: '-86% Friction' },
    ],
    livePreviewStats: {
      lighthouse: 100,
      fps: 60,
      ttfb: '42ms',
      uptime: '99.98%',
    },
    clientQuote: {
      text: 'Moin turned our complex multi-agent backend into an interface that feels effortless and futuristic. We hit #1 Product of the Day on launch.',
      author: 'Dr. Elena Rostova',
      role: 'Co-Founder & CEO, Chronos AI',
    },
  },
  {
    id: 'monolith-audio',
    index: '05',
    title: 'MONOLITH AUDIO',
    subtitle: 'Brutalist Modular Synthesizer Store & Live WebAudio Patch Lab',
    client: 'Monolith Instruments GmbH',
    location: 'Berlin, Germany',
    year: '2024',
    duration: '5 Weeks',
    category: 'WebGL & Motion',
    featured: false,
    accentColor: '#E2FF32',
    secondaryColor: '#FF4D2D',
    metricBadge: '+128% Direct Sales',
    metricDetail: 'Interactive Browser Synth Engine',
    summary:
      'An interactive hardware synthesizer showcase where musicians can patch cables, twist tactile rotary knobs, and audition real analog oscillators directly in the browser.',
    challenge:
      'Selling $2,400 hardware synthesizers online required letting producers truly hear and interact with the signal path before purchasing.',
    architecture:
      'Coupled a custom WebAudio DSP oscillator graph with tactile SVG rotary encoders and physics-based patch cable catenary curves.',
    typographyNote:
      'Inspired by 1970s German industrial synth faceplates—bold stencil numerals, technical schematics, and laser-etched hairline grids.',
    deliverables: [
      'Playable In-Browser WebAudio Modular Synth',
      'Physics-Based Patch Cable Routing UI',
      'Hardware Pre-Order & Batch Queue System',
      'Interactive Audio Oscilloscope Visualizer',
    ],
    stack: ['WebAudio API', 'React', 'SVG Physics', 'TypeScript', 'Stripe API'],
    benchmarks: [
      { label: 'Avg. Session Duration', before: '1m 12s', after: '6m 48s', improvement: '+466% Engagement' },
      { label: 'Direct Hardware Pre-Orders', before: '140 / mo', after: '319 / mo', improvement: '+128% Lift' },
      { label: 'Audio Latency', before: 'N/A', after: '< 8ms', improvement: 'Real-Time DSP' },
    ],
    livePreviewStats: {
      lighthouse: 98,
      fps: 60,
      ttfb: '49ms',
      uptime: '100%',
    },
    clientQuote: {
      text: 'Producers spend seven minutes playing our synth right on the homepage before hitting buy. Freelancer MK built something nobody in our industry thought was possible on the web.',
      author: 'Henrik Lindqvist',
      role: 'Founder, Monolith Berlin',
    },
  },
  {
    id: 'vanguard-ventures',
    index: '06',
    title: 'VANGUARD VENTURES',
    subtitle: 'Editorial Venture Flagship & Interactive Cap-Table Simulator',
    client: 'Vanguard Capital Partners',
    location: 'New York, USA',
    year: '2025',
    duration: '3 Weeks',
    category: 'WebGL & Motion',
    featured: false,
    accentColor: '#F59E0B',
    secondaryColor: '#E2FF32',
    metricBadge: '$180M Fund II Closed',
    metricDetail: '3.2x Founder Inbound Deal Flow',
    summary:
      'Replaced a static corporate VC website with an authoritative editorial publication and interactive dilution & exit waterfall calculator for technical founders.',
    challenge:
      'Vanguard wanted to stand apart from generic Silicon Valley VC templates and provide immediate utility to deep-tech founders.',
    architecture:
      'Built an ultra-fast static-first editorial engine with interactive financial modeling tools and kinetic typography transitions.',
    typographyNote:
      'Monumental Fraunces & Instrument Serif editorial headlines juxtaposed with Bloomberg-inspired tabular financial matrices.',
    deliverables: [
      'Interactive Founder Dilution & Waterfall Calculator',
      'Portfolio Thesis Monograph Engine',
      'LP Secure Data-Room Portal Preview',
      'Automated CMS Deal-Flow Integration',
    ],
    stack: ['Next.js', 'TypeScript', 'Tailwind CSS', 'Motion', 'MDX Editorial'],
    benchmarks: [
      { label: 'Qualified Founder Pitches', before: '28 / mo', after: '89 / mo', improvement: '3.2x Inbound' },
      { label: 'Lighthouse Performance', before: '68', after: '100', improvement: 'Perfect 100' },
      { label: 'Calculator Usage Rate', before: '0%', after: '64% of Visitors', improvement: 'High Utility' },
    ],
    livePreviewStats: {
      lighthouse: 100,
      fps: 60,
      ttfb: '29ms',
      uptime: '100%',
    },
    clientQuote: {
      text: 'Founders literally mention our website in their first pitch meeting. Moin gave our firm an unmistakable typographic voice.',
      author: 'general Partner Sarah Jenkins',
      role: 'Managing Partner, Vanguard NYC',
    },
  },
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'srv-fullstack',
    code: 'SRV // 01',
    title: 'Full-Stack Web & Product Engineering',
    editorialTag: 'Sub-Second Production Architecture',
    shortDesc:
      'End-to-end engineering of resilient SaaS platforms, real-time dashboards, and scalable web applications engineered for speed and longevity.',
    detailedDesc:
      'From database schema modeling and edge API orchestration to pixel-exact reactive frontends. Every application is built with strict TypeScript safety, optimistic UI updates, and sub-second Core Web Vitals.',
    turnaround: '3 – 6 Weeks',
    startingAtUSD: 3800,
    deliverables: [
      'Next.js 15 / React 19 Full-Stack Architecture',
      'PostgreSQL / Supabase / Prisma Schema & API Layer',
      'Authentication, RBAC & Stripe Billing Flows',
      'Realtime WebSockets & Edge Caching Strategy',
      'Automated CI/CD & Production Telemetry Setup',
    ],
    technologies: ['Next.js 15', 'React 19', 'TypeScript', 'Node.js', 'PostgreSQL', 'Supabase', 'Stripe'],
    idealFor: 'Founders & Product Teams launching a flagship SaaS MVP or scaling an existing platform.',
    outcomeMetric: '99.99% Uptime & 100 Lighthouse Target',
  },
  {
    id: 'srv-uiux',
    code: 'SRV // 02',
    title: 'Uncommon UI/UX & Editorial Design Systems',
    editorialTag: 'Avant-Garde Typography & Interface Craft',
    shortDesc:
      'Bespoke visual direction, kinetic front-text typography systems, and tokenized component libraries that refuse to look like generic templates.',
    detailedDesc:
      'I blend Swiss architectural grids with expressive display typography (Syne, Instrument Serif, Fraunces, Space Mono) to craft interfaces that command authority and elevate brand perception while remaining effortlessly usable.',
    turnaround: '2 – 4 Weeks',
    startingAtUSD: 2600,
    deliverables: [
      'Bespoke Typography & Visual Identity Direction',
      'High-Fidelity Interactive Figma Prototypes',
      'Tokenized Dark/Light Mode Design System',
      'Production React + Tailwind v4 Component Kit',
      'WCAG AAA Contrast & Keyboard Navigation Audit',
    ],
    technologies: ['Figma Variables', 'Design Tokens', 'Tailwind CSS v4', 'Radix Primitives', 'Storybook'],
    idealFor: 'Brands & tech companies ready to graduate from generic templates into an iconic category leader.',
    outcomeMetric: '+45% to +120% Brand Authority & Engagement Lift',
  },
  {
    id: 'srv-ecommerce',
    code: 'SRV // 03',
    title: 'High-Conversion Headless Commerce & Motion',
    editorialTag: 'Kinetic Scrollytelling & Express Checkout',
    shortDesc:
      'Luxury-grade storefronts and interactive product flagships engineered to maximize conversion velocity and average order value.',
    detailedDesc:
      'Merging fluid 60fps micro-interactions, WebGL visualizers, and zero-reload page transitions with battle-tested checkout pipelines (Shopify Headless, Stripe Custom Checkout).',
    turnaround: '3 – 5 Weeks',
    startingAtUSD: 3200,
    deliverables: [
      'Headless Shopify or Custom Stripe Storefront',
      'Interactive Product Configurators & Lookbooks',
      'Slide-Over 1-Click Cart & Upsell Engine',
      'Technical SEO, Schema Markup & OpenGraph Engine',
      'Sub-Second Global CDN Edge Deployment',
    ],
    technologies: ['Shopify Storefront API', 'Stripe', 'WebGL / Three.js', 'Motion', 'Next.js Commerce'],
    idealFor: 'D2C brands, hardware creators, and digital product studios seeking higher checkout conversion.',
    outcomeMetric: 'Avg. +58% Conversion Rate Optimization',
  },
  {
    id: 'srv-ai',
    code: 'SRV // 04',
    title: 'AI-Native Interfaces & Agentic Workflows',
    editorialTag: 'Streaming LLM UX & Spatial Canvases',
    shortDesc:
      'Next-generation interfaces for AI products: streaming generative UI, multi-agent node canvases, RAG knowledge workspaces, and prompt IDEs.',
    detailedDesc:
      'Move beyond basic chat boxes. I design and engineer deterministic, low-latency AI interfaces with real-time token streaming, citation verification drawers, and human-in-the-loop approval flows.',
    turnaround: '2 – 5 Weeks',
    startingAtUSD: 3500,
    deliverables: [
      'Streaming Generative UI & Tool-Call Renderers',
      'Spatial Node Canvas or Split-Pane Artifact Workspace',
      'OpenAI / Anthropic / Vercel AI SDK Integration',
      'Token Usage & Latency Telemetry Dashboard',
      'Prompt Versioning & Evaluation UI',
    ],
    technologies: ['Vercel AI SDK', 'OpenAI / Claude API', 'Server-Sent Events', 'Canvas API', 'TypeScript'],
    idealFor: 'AI startups and enterprise teams embedding generative workflows into customer-facing products.',
    outcomeMetric: '3.4x Faster User Task Completion',
  },
];

export const OFFER_TIERS: OfferTier[] = [
  {
    id: 'offer-audit',
    code: 'TIER // 01',
    name: 'UI/UX & Performance Architecture Audit',
    tagline: 'Rapid High-Impact Diagnostic & Actionable Refactor Blueprint',
    sprintPriceUSD: 1250,
    retainerPriceUSD: 1050,
    durationLabel: '5-Day Turnaround',
    capacityStatus: 'Immediate Start Available',
    description:
      'A surgical teardown of your live product or landing page covering typography hierarchy, conversion bottlenecks, bundle bloat, and Core Web Vitals.',
    features: [
      'Full 40-Point UI/UX & Typography Critique Video + Deck',
      'Redesign of Your Top-Fold Hero in Figma + Production Code',
      'Lighthouse & Core Web Vitals Bottleneck Flamegraph',
      'Conversion Funnel Friction Map & Quick-Win Checklist',
      '60-Minute Live Strategy & Engineering Walkthrough',
    ],
    guarantees: ['100% Credited Toward Any Full Sprint Within 30 Days', 'Delivered in 5 Business Days Guaranteed'],
    ctaLabel: 'Book 5-Day Audit',
  },
  {
    id: 'offer-mvp',
    code: 'TIER // 02',
    name: 'Flagship Product / MVP Launchpad Sprint',
    tagline: 'Zero-to-One Design + Full-Stack Production Delivery',
    badge: 'MOST SELECTED BY FOUNDERS',
    highlighted: true,
    sprintPriceUSD: 4400,
    retainerPriceUSD: 3740,
    durationLabel: '3 – 4 Week Dedicated Sprint',
    capacityStatus: '1 Slot Open for May',
    description:
      'The complete Moin Uddin Khan signature engagement: bespoke uncommon typography, full UI/UX architecture, and production-ready Next.js/TypeScript code.',
    features: [
      'Complete Bespoke Visual Direction & Uncommon Front-Text System',
      'Up to 10 Custom Views / Interactive App Modules',
      'Production Next.js 15 + TypeScript + Tailwind v4 Codebase',
      'CMS, Auth, Database or Stripe Payment Integration',
      '60fps Micro-Interactions & Responsive Mobile Perfection',
      'Direct Async Slack/Loom Updates Every 48 Hours',
    ],
    guarantees: ['Guaranteed 98+ Lighthouse Performance Score', '30 Days Post-Launch Bug & Polish Warranty'],
    ctaLabel: 'Lock MVP Sprint Slot',
  },
  {
    id: 'offer-retainer',
    code: 'TIER // 03',
    name: 'Dedicated Principal Partner Retainer',
    tagline: 'Fractional Founding Engineer & Principal Design Director',
    sprintPriceUSD: 5800,
    retainerPriceUSD: 4930,
    durationLabel: 'Monthly Ongoing // Cancel Anytime',
    capacityStatus: '1 Retainer Seat Remaining',
    description:
      'Embed Freelancer MK directly into your leadership squad for continuous feature velocity, design system stewardship, and conversion experiments.',
    features: [
      'Unlimited Prioritized Design & Full-Stack Engineering Backlog',
      '48-Hour Average Turnaround on Active Sprint Tasks',
      'Continuous Design System & Component Library Expansion',
      'Weekly Executive Architecture & Growth Sync (or 100% Async)',
      'Priority Emergency Hotfix & Launch Support SLA',
      'Pause or Roll Over Unused Days Anytime',
    ],
    guarantees: ['Zero Overhead vs. $180k/yr Senior Full-Time Hire', 'Pause or Cancel with 7 Days Notice'],
    ctaLabel: 'Reserve Partner Seat',
  },
];

export const FLASH_OFFERS: FlashOffer[] = [
  {
    id: 'flash-hero',
    code: 'SPECIAL OFFER // 01',
    title: '72-Hour Hero & Uncommon Front-Text Makeover',
    subtitle: 'Transform your top-fold from generic SaaS template to Awwwards-grade editorial authority.',
    discountBadge: 'SAVE $650 // LIMITED',
    originalUSD: 1600,
    offerUSD: 950,
    turnaround: '72 Hours',
    slotsRemaining: 2,
    description:
      '75% of visitors decide your brand’s credibility in 3 seconds. I will re-architect and code your entire Hero section, navigation bar, and kinetic typography system.',
    includes: [
      'Bespoke Uncommon Font Pairing (Syne / Instrument Serif / Mono)',
      'Production React / Tailwind Component (Drop-In Ready)',
      'Interactive Above-the-Fold Product Preview or Micro-Demo',
      'Copywriting Polish for Maximum Value Proposition Clarity',
    ],
  },
  {
    id: 'flash-figma-code',
    code: 'SPECIAL OFFER // 02',
    title: 'Figma-to-React 100-Lighthouse Express Sprint',
    subtitle: 'Already have Figma designs? Get pixel-exact, accessible TypeScript code in 5 business days.',
    discountBadge: '25% FOUNDER RATE',
    originalUSD: 2800,
    offerUSD: 2100,
    turnaround: '5 Business Days',
    slotsRemaining: 2,
    description:
      'No bloated page-builders. Clean, semantic, maintainable React 19 + Tailwind CSS v4 components with fluid responsive scaling and silky animations.',
    includes: [
      'Up to 5 Full Pages or Complex Dashboard Views',
      'Strict TypeScript Props & Reusable Atomic Components',
      '60fps Scroll & Hover Micro-Interactions',
      'Vercel / Netlify Edge Deployment & Custom Domain Setup',
    ],
  },
  {
    id: 'flash-pitch',
    code: 'SPECIAL OFFER // 03',
    title: 'Seed/Series-A Interactive Web Pitch + Prototype',
    subtitle: 'Replace static PDF pitch decks with an interactive password-protected investor web experience.',
    discountBadge: 'INVESTOR READY',
    originalUSD: 3400,
    offerUSD: 2550,
    turnaround: '7 Days',
    slotsRemaining: 1,
    description:
      'Give VCs and enterprise buyers a live playable product prototype and interactive ROI/traction model they can experience in their browser.',
    includes: [
      'Interactive Clickable Product Prototype in Real Code',
      'Live Financial / Traction Calculator Module',
      'Investor Access Analytics & Custom Passcode Gate',
      'Mobile & iPad Pro Presentation Mode',
    ],
  },
  {
    id: 'flash-teardown',
    code: 'COMPLIMENTARY // 04',
    title: 'Free 20-Min Live Architecture & Typography Roast',
    subtitle: 'No sales fluff—get 5 immediate visual & engineering upgrades you can apply today.',
    discountBadge: '100% FREE FOR FOUNDERS',
    originalUSD: 350,
    offerUSD: 0,
    turnaround: 'Within 48 Hours',
    slotsRemaining: 3,
    description:
      'Send me your current URL. I will record a personalized Loom video dissecting your typography, layout rhythm, and frontend performance with concrete fixes.',
    includes: [
      'Personalized 10-Minute Loom Video Breakdown by MK',
      'Custom Uncommon Font Pairing Recommendation for Your Brand',
      'Top 3 Conversion & Speed Bottlenecks Identified',
      'Zero Obligation—Keep the Blueprint Either Way',
    ],
  },
];

export const REVIEWS: ReviewItem[] = [
  {
    id: 'rev-01',
    index: 'REV // 01',
    clientName: 'Lukas Vance',
    role: 'Chief Technology Officer',
    company: 'Aetheria Labs AG',
    location: 'Zurich, Switzerland',
    category: 'Fintech',
    rating: 5.0,
    date: 'February 2025',
    projectDelivered: 'Institutional Orderbook Terminal & Design System',
    verifiedImpact: '+310% UI Frame Rate & $42M Monthly Volume',
    headlineQuote:
      'Moin architected a frontend that feels like a defense-grade cockpit. Our institutional desk volume tripled within 45 days.',
    fullReview:
      'We interviewed four agencies before discovering Moin Uddin Khan (Freelancer MK). Most designers cannot code high-frequency WebSocket buffers, and most systems engineers lack typographic taste. Moin delivered both at an extraordinary level. His tabular monospace hierarchy eliminated visual jitter entirely.',
    budgetRange: '$10,000 – $15,000',
  },
  {
    id: 'rev-02',
    index: 'REV // 02',
    clientName: 'Céline Moreau',
    role: 'Executive Creative Director',
    company: 'Kinetix Atelier',
    location: 'Paris, France',
    category: 'E-Commerce',
    rating: 5.0,
    date: 'January 2025',
    projectDelivered: 'Headless Luxury Storefront & Kinetic Typography System',
    verifiedImpact: '+64% Checkout Conversion & 19-Minute Drop Sellout',
    headlineQuote:
      'MK possesses that rare duality: the eye of an avant-garde Parisian art director and the rigor of a principal systems engineer.',
    fullReview:
      'Our brand relies on uncommon editorial typography and tactile motion. Moin introduced a custom Syne and Instrument Serif pairing with WebGL transitions that made our digital flagship feel like a physical gallery. Checkout conversion jumped 64% on day one.',
    budgetRange: '$5,000 – $10,000',
  },
  {
    id: 'rev-03',
    index: 'REV // 03',
    clientName: 'Marcus Chen',
    role: 'VP of Engineering',
    company: 'Veridian Infrastructure',
    location: 'San Francisco, USA',
    category: 'Design Systems',
    rating: 5.0,
    date: 'November 2024',
    projectDelivered: '140-Component Cloud OS Design System',
    verifiedImpact: '48% Faster Feature Shipping & -84% Bundle Size',
    headlineQuote:
      'Working with Freelancer MK saved us from hiring three full-time frontend engineers. His TypeScript architecture is immaculate.',
    fullReview:
      'Moin audited our four fragmented dashboards and unified them into a single keyboard-first design system in under eight weeks. Every component met WCAG AAA standards, and our JavaScript payload dropped from 2.1MB to 340KB.',
    budgetRange: '$15,000+',
  },
  {
    id: 'rev-04',
    index: 'REV // 04',
    clientName: 'Dr. Elena Rostova',
    role: 'Co-Founder & CEO',
    company: 'Chronos Neural AI',
    location: 'London, UK',
    category: 'SaaS & AI',
    rating: 5.0,
    date: 'March 2025',
    projectDelivered: 'Multi-Agent Spatial Canvas & Product Launch Site',
    verifiedImpact: '#1 Product of the Day & 3.6x Signup Conversion',
    headlineQuote:
      'Moin turned our complex multi-agent backend into an interface that feels effortless and futuristic.',
    fullReview:
      'We needed both an iconic marketing website with uncommon typography and a deeply technical node-graph IDE. Moin shipped both ahead of schedule. Investors repeatedly complimented the craft of our interface during our seed round.',
    budgetRange: '$5,000 – $10,000',
  },
  {
    id: 'rev-05',
    index: 'REV // 05',
    clientName: 'Henrik Lindqvist',
    role: 'Founder & Lead Designer',
    company: 'Monolith Audio GmbH',
    location: 'Berlin, Germany',
    category: 'E-Commerce',
    rating: 5.0,
    date: 'September 2024',
    projectDelivered: 'Interactive WebAudio Synthesizer Flagship',
    verifiedImpact: '+128% Direct Hardware Pre-Orders',
    headlineQuote:
      'Producers spend nearly seven minutes playing our synth right on the homepage before hitting buy.',
    fullReview:
      'Moin built a live modular synthesizer inside the browser with physics-based patch cables and industrial stencil typography. It became viral across music production forums and doubled our direct-to-consumer sales.',
    budgetRange: '$5,000 – $10,000',
  },
  {
    id: 'rev-06',
    index: 'REV // 06',
    clientName: 'Sarah Jenkins',
    role: 'Managing Partner',
    company: 'Vanguard Ventures',
    location: 'New York, USA',
    category: 'Fintech',
    rating: 5.0,
    date: 'December 2024',
    projectDelivered: 'Editorial Venture Portal & Cap-Table Simulator',
    verifiedImpact: '3.2x Qualified Founder Inbound Deal Flow',
    headlineQuote:
      'Founders literally mention our website in their first pitch meeting. Moin gave our firm an unmistakable typographic voice.',
    fullReview:
      'Fast, communicative, and zero hand-holding required. We started with Moin’s 72-Hour Hero Makeover offer and were so blown away that we commissioned him for our entire web platform and founder calculator suite.',
    budgetRange: '$5,000 – $10,000',
  },
];

export const TYPOGRAPHY_SPECIMENS = [
  {
    id: 'spec-01',
    name: '01 // KINETIC BRUTALIST MIX',
    fontsUsed: 'Syne 800 ExtraBold + Instrument Serif Italic + Space Mono',
    character: 'High-impact architectural contrast. Wide geometric uppercase meets razor-sharp couture serifs.',
    samplePrimary: 'ARCHITECTING UNCOMMON',
    sampleAccent: 'digital monopolies',
    sampleSub: 'SUB-SECOND FULL-STACK SYSTEMS // MK STUDIO',
  },
  {
    id: 'spec-02',
    name: '02 // EDITORIAL COUTURE MONOGRAPH',
    fontsUsed: 'Instrument Serif Regular/Italic + Fraunces Optical + Plus Jakarta',
    character: 'Luxury publication authority. Ideal for venture firms, fashion flagships, and high-trust founders.',
    samplePrimary: 'Precision is the quietest',
    sampleAccent: 'FORM OF AUTHORITY',
    sampleSub: 'BESPOKE TYPOGRAPHIC ENGINEERING // EST. 2019',
  },
  {
    id: 'spec-03',
    name: '03 // HOLLOW WIREFRAME KINETIC',
    fontsUsed: 'Syne Outlined Stroke 1.5px + Solid Volt Yellow Counterpoint',
    character: 'Avant-garde brutalist brutalism with zero visual heaviness and interactive hover fill states.',
    samplePrimary: 'ZERO TEMPLATE',
    sampleAccent: 'PURE CRAFT',
    sampleSub: 'INTERACTIVE VECTOR TYPOGRAPHY ENGINE',
  },
];

export const FAQS = [
  {
    q: 'How quickly can we start a new project or sprint offer?',
    a: 'For Flash Offers and 5-Day Audits, I can typically begin within 48 hours of onboarding. For full 3–4 Week MVP Launchpad Sprints, I take on a maximum of 2 concurrent clients per month to ensure principal-level focus.',
  },
  {
    q: 'Do you handle both the UI/UX Design (including uncommon typography) and the Full-Stack Code?',
    a: 'Yes—100%. That is the core advantage of working with Freelancer MK. Nothing gets lost in translation between Figma and production engineering because the same brain architects your typographic identity, interaction physics, and Next.js/TypeScript codebase.',
  },
  {
    q: 'What if I only need frontend/UI engineering or only need design?',
    a: 'Both are supported. Many clients hire me via the "Figma-to-React Express" offer to turn existing designs into 100-Lighthouse production code, while others bring a backend team and hire me strictly for UI/UX Architecture and Frontend Systems.',
  },
  {
    q: 'How does communication work across timezones?',
    a: 'I operate an async-first studio model using dedicated Slack channels, 48-hour Loom video walkthroughs, and live staging links so you never wonder about progress—plus overlapping live sync hours for European, US, and Asian timezones.',
  },
  {
    q: 'Do I own 100% of the source code, Figma files, and IP?',
    a: 'Absolutely. Upon completion, you receive full repository ownership, Figma design systems, custom font configurations, and deployment pipelines with zero lock-in.',
  },
];
