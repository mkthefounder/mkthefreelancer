import React, { useState } from 'react';
import { FrontTextStyle, PROJECTS, ProjectItem } from '../data/mkData';
import { UncommonHeadline } from '../components/UncommonHeadline';
import { ProjectVisualCanvas } from '../components/ProjectVisualCanvas';
import {
  ArrowUpRight,
  Filter,
  LayoutGrid,
  List,
  SlidersHorizontal,
  Sparkles,
} from 'lucide-react';

interface WorkPageProps {
  frontTextStyle: FrontTextStyle;
  onSelectProject: (project: ProjectItem) => void;
  onOpenBooking: (presetContext?: string) => void;
}

const CATEGORIES = [
  'All',
  'Full-Stack',
  'UI/UX Architecture',
  'E-Commerce',
  'WebGL & Motion',
  'AI Systems',
] as const;

export const WorkPage: React.FC<WorkPageProps> = ({
  frontTextStyle,
  onSelectProject,
  onOpenBooking,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [viewMode, setViewMode] = useState<'grid' | 'ledger'>('grid');
  const [refactorSplit, setRefactorSplit] = useState<number>(72);

  const filteredProjects =
    selectedCategory === 'All'
      ? PROJECTS
      : PROJECTS.filter((p) => p.category === selectedCategory);

  return (
    <div className="px-4 sm:px-8 max-w-[1440px] mx-auto pt-8 sm:pt-12 pb-24 space-y-16">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 border-b border-[#F4F3EF]/10 pb-8">
        <div className="space-y-4 max-w-3xl">
          <UncommonHeadline
            kicker="PAGE 02 // CURATED CASE STUDIES (2023 – 2026)"
            primaryText="ARCHITECTURAL"
            editorialAccent="selected works"
            secondaryText="& SHIPPED SYSTEMS"
            frontTextStyle={frontTextStyle}
            size="banner"
          />
          <p className="font-jakarta text-base sm:text-lg text-[#9A9EA7] leading-relaxed">
            Every project in Moin Uddin Khan’s archive is custom-engineered from zero—pairing
            uncommon display typography with deterministic full-stack code and measurable revenue
            lift.
          </p>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center gap-2 self-start lg:self-end">
          <span className="font-mono-tech text-xs text-[#9A9EA7] mr-1 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-[#E2FF32]" /> VIEW:
          </span>
          <div className="flex items-center p-1 rounded-xl bg-[#13151A] border border-[#F4F3EF]/12">
            <button
              onClick={() => setViewMode('grid')}
              className={`px-3 py-1.5 rounded-lg font-mono-tech text-xs flex items-center gap-1.5 transition-all ${
                viewMode === 'grid'
                  ? 'bg-[#E2FF32] text-[#0B0C0E] font-bold'
                  : 'text-[#9A9EA7] hover:text-[#F4F3EF]'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Editorial Grid</span>
            </button>
            <button
              onClick={() => setViewMode('ledger')}
              className={`px-3 py-1.5 rounded-lg font-mono-tech text-xs flex items-center gap-1.5 transition-all ${
                viewMode === 'ledger'
                  ? 'bg-[#E2FF32] text-[#0B0C0E] font-bold'
                  : 'text-[#9A9EA7] hover:text-[#F4F3EF]'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Index Ledger</span>
            </button>
          </div>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex flex-wrap items-center gap-2">
        {CATEGORIES.map((cat) => {
          const active = selectedCategory === cat;
          const count =
            cat === 'All'
              ? PROJECTS.length
              : PROJECTS.filter((p) => p.category === cat).length;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2.5 rounded-full font-mono-tech text-xs transition-all border flex items-center gap-2 ${
                active
                  ? 'bg-[#F4F3EF] text-[#0B0C0E] border-[#F4F3EF] font-bold shadow-md'
                  : 'bg-[#13151A] text-[#9A9EA7] border-[#F4F3EF]/10 hover:border-[#E2FF32]/50 hover:text-[#F4F3EF]'
              }`}
            >
              <span>{cat}</span>
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                  active ? 'bg-[#0B0C0E] text-[#E2FF32]' : 'bg-[#0B0C0E] text-[#9A9EA7]'
                }`}
              >
                0{count}
              </span>
            </button>
          );
        })}
      </div>

      {/* View Mode 1: Editorial Split Showcase Grid */}
      {viewMode === 'grid' ? (
        <div className="space-y-10">
          {filteredProjects.map((project, idx) => {
            const isEven = idx % 2 === 0;
            return (
              <div
                key={project.id}
                onClick={() => onSelectProject(project)}
                className="group cursor-pointer rounded-3xl bg-[#13151A] border border-[#F4F3EF]/12 hover:border-[#E2FF32] p-6 sm:p-9 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center transition-all duration-300 shadow-2xl"
              >
                {/* Visual Preview Column */}
                <div
                  className={`lg:col-span-6 h-[290px] sm:h-[330px] ${
                    isEven ? 'lg:order-1' : 'lg:order-2'
                  }`}
                >
                  <ProjectVisualCanvas project={project} interactive />
                </div>

                {/* Architectural Dossier Column */}
                <div
                  className={`lg:col-span-6 space-y-5 ${
                    isEven ? 'lg:order-2' : 'lg:order-1'
                  }`}
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono-tech text-xs px-2.5 py-1 rounded bg-[#E2FF32] text-[#0B0C0E] font-bold">
                      ARCHIVE // {project.index}
                    </span>
                    <span className="font-mono-tech text-xs px-3 py-1 rounded-full bg-[#0B0C0E] border border-[#F4F3EF]/12 text-[#F4F3EF]">
                      {project.category}
                    </span>
                    <span className="font-mono-tech text-xs text-[#9A9EA7]">
                      {project.client} • {project.location}
                    </span>
                  </div>

                  <div>
                    <h2 className="font-syne font-extrabold text-3xl sm:text-4xl text-[#F4F3EF] group-hover:text-[#E2FF32] transition-colors uppercase">
                      {project.title}
                    </h2>
                    <p className="font-editorial italic text-2xl sm:text-3xl text-[#E2FF32] mt-1">
                      {project.subtitle}
                    </p>
                  </div>

                  <p className="font-jakarta text-sm sm:text-base text-[#9A9EA7] leading-relaxed">
                    {project.summary}
                  </p>

                  {/* Benchmark Mini-Row */}
                  <div className="grid grid-cols-3 gap-2.5 pt-1">
                    {project.benchmarks.map((b) => (
                      <div
                        key={b.label}
                        className="p-3 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/10"
                      >
                        <div className="font-mono-tech text-[10px] text-[#9A9EA7] truncate">
                          {b.label}
                        </div>
                        <div className="font-syne font-extrabold text-base sm:text-lg text-[#F4F3EF] mt-0.5">
                          {b.improvement}
                        </div>
                        <div className="font-mono-tech text-[10px] text-[#10B981]">
                          {b.before} → {b.after}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Stack & Action */}
                  <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-[#F4F3EF]/10">
                    <div className="flex flex-wrap gap-1.5">
                      {project.stack.map((tech) => (
                        <span
                          key={tech}
                          className="font-mono-tech text-[11px] px-2.5 py-1 rounded-md bg-[#0B0C0E] text-[#9A9EA7] border border-[#F4F3EF]/10"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>

                    <span className="inline-flex items-center gap-1.5 font-syne font-bold text-xs uppercase tracking-wider text-[#E2FF32] group-hover:translate-x-1 transition-transform">
                      <span>Read Full Case Study</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* View Mode 2: Swiss Architectural Ledger Table */
        <div className="rounded-3xl bg-[#13151A] border border-[#F4F3EF]/15 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#F4F3EF]/12 bg-[#0B0C0E] font-mono-tech text-[11px] uppercase tracking-wider text-[#9A9EA7]">
                  <th className="py-4 px-5">Index</th>
                  <th className="py-4 px-5">Project & Uncommon Subtitle</th>
                  <th className="py-4 px-5">Client & Location</th>
                  <th className="py-4 px-5">Discipline</th>
                  <th className="py-4 px-5">Verified Outcome</th>
                  <th className="py-4 px-5 text-right">Dossier</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F4F3EF]/10">
                {filteredProjects.map((project) => (
                  <tr
                    key={project.id}
                    onClick={() => onSelectProject(project)}
                    className="group cursor-pointer hover:bg-[#1b1e26] transition-colors"
                  >
                    <td className="py-5 px-5 font-mono-tech text-xs text-[#E2FF32] font-bold">
                      [{project.index}]
                    </td>
                    <td className="py-5 px-5">
                      <div className="font-syne font-extrabold text-lg text-[#F4F3EF] group-hover:text-[#E2FF32] transition-colors">
                        {project.title}
                      </div>
                      <div className="font-editorial italic text-base text-[#9A9EA7]">
                        {project.subtitle}
                      </div>
                    </td>
                    <td className="py-5 px-5 font-mono-tech text-xs text-[#F4F3EF]">
                      <div>{project.client}</div>
                      <div className="text-[#9A9EA7] text-[11px]">{project.location}</div>
                    </td>
                    <td className="py-5 px-5">
                      <span className="font-mono-tech text-xs px-2.5 py-1 rounded-full bg-[#0B0C0E] border border-[#F4F3EF]/12 text-[#F4F3EF]">
                        {project.category}
                      </span>
                    </td>
                    <td className="py-5 px-5">
                      <span className="font-mono-tech text-xs font-bold text-[#10B981]">
                        {project.metricBadge}
                      </span>
                      <div className="font-mono-tech text-[10px] text-[#9A9EA7]">
                        Lighthouse {project.livePreviewStats.lighthouse}/100
                      </div>
                    </td>
                    <td className="py-5 px-5 text-right">
                      <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#0B0C0E] group-hover:bg-[#E2FF32] text-[#F4F3EF] group-hover:text-[#0B0C0E] font-mono-tech text-xs transition-colors">
                        <span>Inspect</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* INTERACTIVE BEFORE / AFTER MK REFACTOR LAB */}
      <div className="rounded-3xl bg-[#13151A] border border-[#F4F3EF]/15 p-6 sm:p-10 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32] mb-2">
              <SlidersHorizontal className="w-4 h-4" /> INTERACTIVE ARCHITECTURE COMPARISON
            </div>
            <h3 className="font-syne font-extrabold text-2xl sm:text-4xl text-[#F4F3EF]">
              Ordinary Template vs.{' '}
              <span className="font-editorial italic font-normal text-[#E2FF32]">
                Freelancer MK Refactor
              </span>
            </h3>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-mono-tech text-xs text-[#9A9EA7]">DRAG IMPACT RATIO:</span>
            <input
              type="range"
              min={15}
              max={90}
              value={refactorSplit}
              onChange={(e) => setRefactorSplit(Number(e.target.value))}
              className="w-36 accent-[#E2FF32] cursor-pointer"
            />
            <span className="font-mono-tech text-xs text-[#E2FF32] font-bold">
              {refactorSplit}% MK
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Before Card */}
          <div className="lg:col-span-5 rounded-2xl bg-[#0B0C0E]/70 border border-[#F4F3EF]/10 p-6 flex flex-col justify-between opacity-75">
            <div className="space-y-3">
              <span className="font-mono-tech text-[10px] uppercase px-2.5 py-1 rounded bg-[#FF4D2D]/20 text-[#FF4D2D]">
                BEFORE // GENERIC SAAS TEMPLATE
              </span>
              <div className="font-jakarta font-bold text-xl text-[#9A9EA7]">
                “Welcome to Our Cloud Platform Solution”
              </div>
              <p className="font-jakarta text-xs text-[#5E626E]">
                Overused system fonts, cluttered 5-column cards, 3.8s LCP load time, and indistinguishable visual identity.
              </p>
            </div>
            <div className="pt-6 mt-6 border-t border-[#F4F3EF]/10 grid grid-cols-3 gap-2 font-mono-tech text-xs">
              <div>
                <div className="text-[10px] text-[#5E626E]">CONVERSION</div>
                <div className="text-[#FF4D2D] font-bold">1.4%</div>
              </div>
              <div>
                <div className="text-[10px] text-[#5E626E]">LIGHTHOUSE</div>
                <div className="text-[#FF4D2D] font-bold">62 / 100</div>
              </div>
              <div>
                <div className="text-[10px] text-[#5E626E]">MEMORABILITY</div>
                <div className="text-[#FF4D2D] font-bold">LOW</div>
              </div>
            </div>
          </div>

          {/* After MK Card */}
          <div className="lg:col-span-7 rounded-2xl bg-[#0B0C0E] border-2 border-[#E2FF32] p-6 sm:p-7 flex flex-col justify-between relative overflow-hidden">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-mono-tech text-[10px] uppercase px-2.5 py-1 rounded bg-[#E2FF32] text-[#0B0C0E] font-bold">
                  AFTER // MOIN UDDIN KHAN BESPOKE ARCHITECTURE
                </span>
                <span className="font-mono-tech text-xs text-[#10B981]">
                  ▲ +240% CONVERSION LIFT
                </span>
              </div>
              <div className="font-syne font-extrabold text-2xl sm:text-3xl text-[#F4F3EF] tracking-tight">
                SOVEREIGN EDGE{' '}
                <span className="font-editorial italic font-normal text-[#E2FF32]">
                  at sub-millisecond scale.
                </span>
              </div>
              <p className="font-jakarta text-xs sm:text-sm text-[#9A9EA7]">
                Monumental Syne + Instrument Serif front-text hierarchy, interactive telemetry
                preview in the hero, and 0.4s instant edge routing.
              </p>
            </div>

            <div className="pt-6 mt-6 border-t border-[#F4F3EF]/10 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-6 font-mono-tech text-xs">
                <div>
                  <div className="text-[10px] text-[#9A9EA7]">CONVERSION</div>
                  <div className="text-[#E2FF32] font-bold text-base">4.85%</div>
                </div>
                <div>
                  <div className="text-[10px] text-[#9A9EA7]">LIGHTHOUSE</div>
                  <div className="text-[#10B981] font-bold text-base">100 / 100</div>
                </div>
                <div>
                  <div className="text-[10px] text-[#9A9EA7]">TYPOGRAPHY</div>
                  <div className="text-[#F4F3EF] font-bold text-base">BESPOKE</div>
                </div>
              </div>

              <button
                onClick={() =>
                  onOpenBooking('Requesting Full-Stack / Uncommon Typography Refactor')
                }
                className="px-5 py-2.5 rounded-full bg-[#E2FF32] text-[#0B0C0E] font-syne font-bold text-xs uppercase flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Refactor My Product</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
