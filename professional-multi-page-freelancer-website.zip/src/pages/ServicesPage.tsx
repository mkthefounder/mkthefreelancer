import React, { useState } from 'react';
import { FrontTextStyle, SERVICES } from '../data/mkData';
import { UncommonHeadline } from '../components/UncommonHeadline';
import {
  ArrowUpRight,
  Calculator,
  CheckCircle2,
  Cpu,
  Layers,
  Rocket,
  Sparkles,
  Zap,
} from 'lucide-react';

interface ServicesPageProps {
  frontTextStyle: FrontTextStyle;
  onOpenBooking: (presetContext?: string) => void;
}

export const ServicesPage: React.FC<ServicesPageProps> = ({
  frontTextStyle,
  onOpenBooking,
}) => {
  // Interactive Scope Estimator State
  const [selectedDiscipline, setSelectedDiscipline] = useState<string>(SERVICES[0].id);
  const [pageCount, setPageCount] = useState<number>(5);
  const [motionTier, setMotionTier] = useState<'editorial' | 'kinetic' | 'webgl'>('kinetic');
  const [addons, setAddons] = useState<string[]>(['Uncommon Font System', 'Full-Stack API/Auth']);

  const toggleAddon = (addon: string) => {
    setAddons((prev) =>
      prev.includes(addon) ? prev.filter((a) => a !== addon) : [...prev, addon]
    );
  };

  // Calculate live investment estimate
  const baseService = SERVICES.find((s) => s.id === selectedDiscipline) || SERVICES[0];
  const pagesCost = pageCount * 240;
  const motionCost = motionTier === 'editorial' ? 0 : motionTier === 'kinetic' ? 650 : 1400;
  const addonsCost = addons.length * 450;
  const estimatedTotal = baseService.startingAtUSD + pagesCost + motionCost + addonsCost;
  const estimatedWeeks = Math.max(2, Math.min(8, Math.round(pageCount * 0.45 + (motionTier === 'webgl' ? 2 : 1))));

  return (
    <div className="px-4 sm:px-8 max-w-[1440px] mx-auto pt-8 sm:pt-12 pb-24 space-y-20">
      {/* Page Header */}
      <div className="border-b border-[#F4F3EF]/10 pb-8 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
        <div className="space-y-4 max-w-3xl">
          <UncommonHeadline
            kicker="PAGE 03 // PRINCIPAL FREELANCE SERVICES"
            primaryText="END-TO-END"
            editorialAccent="architectural"
            secondaryText="CAPABILITIES"
            frontTextStyle={frontTextStyle}
            size="banner"
          />
          <p className="font-jakarta text-base sm:text-lg text-[#9A9EA7] leading-relaxed">
            Hire Moin Uddin Khan (Freelancer MK) for specialized product design, uncommon front-text
            typography systems, or complete full-stack production engineering.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-[#13151A] border border-[#F4F3EF]/12 font-mono-tech text-xs space-y-1">
          <div className="text-[#E2FF32] font-bold">● DIRECT PRINCIPAL EXECUTION</div>
          <div className="text-[#9A9EA7]">No junior handoffs. 100% written & designed by MK.</div>
        </div>
      </div>

      {/* 4 Core Services Detailed Architectural Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {SERVICES.map((srv) => (
          <div
            key={srv.id}
            className="rounded-3xl bg-[#13151A] border border-[#F4F3EF]/12 hover:border-[#E2FF32]/60 p-7 sm:p-9 flex flex-col justify-between gap-8 transition-all shadow-xl"
          >
            <div className="space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-mono-tech text-xs px-3 py-1 rounded bg-[#E2FF32] text-[#0B0C0E] font-bold">
                  {srv.code}
                </span>
                <div className="flex items-center gap-2">
                  <span className="font-mono-tech text-xs px-3 py-1 rounded-full bg-[#0B0C0E] border border-[#F4F3EF]/12 text-[#9A9EA7]">
                    Cadence: {srv.turnaround}
                  </span>
                  <span className="font-mono-tech text-xs px-3 py-1 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30 font-bold">
                    From ${srv.startingAtUSD.toLocaleString()}
                  </span>
                </div>
              </div>

              <div>
                <h2 className="font-syne font-extrabold text-2xl sm:text-3xl text-[#F4F3EF]">
                  {srv.title}
                </h2>
                <p className="font-editorial italic text-2xl text-[#E2FF32] mt-1">
                  {srv.editorialTag}
                </p>
              </div>

              <p className="font-jakarta text-sm sm:text-base text-[#9A9EA7] leading-relaxed">
                {srv.detailedDesc}
              </p>

              {/* Deliverables Checklist */}
              <div className="space-y-2.5 pt-2">
                <div className="font-mono-tech text-[11px] uppercase tracking-widest text-[#F4F3EF]">
                  INCLUDED ARCHITECTURAL DELIVERABLES:
                </div>
                <div className="grid grid-cols-1 gap-2">
                  {srv.deliverables.map((d) => (
                    <div
                      key={d}
                      className="flex items-start gap-2.5 p-2.5 rounded-xl bg-[#0B0C0E]/70 border border-[#F4F3EF]/8 font-jakarta text-xs sm:text-sm text-[#F4F3EF]"
                    >
                      <CheckCircle2 className="w-4 h-4 text-[#E2FF32] shrink-0 mt-0.5" />
                      <span>{d}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Stack & CTA */}
            <div className="space-y-4 pt-5 border-t border-[#F4F3EF]/10">
              <div className="flex flex-wrap gap-1.5">
                {srv.technologies.map((tech) => (
                  <span
                    key={tech}
                    className="font-mono-tech text-[11px] px-2.5 py-1 rounded-md bg-[#0B0C0E] text-[#9A9EA7] border border-[#F4F3EF]/10"
                  >
                    {tech}
                  </span>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
                <div className="font-mono-tech text-xs text-[#10B981]">
                  Target: {srv.outcomeMetric}
                </div>
                <button
                  onClick={() =>
                    onOpenBooking(`Service Inquiry: ${srv.title} (Starting at $${srv.startingAtUSD})`)
                  }
                  className="px-5 py-3 rounded-full bg-[#F4F3EF] hover:bg-[#E2FF32] text-[#0B0C0E] font-syne font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors"
                >
                  <span>Commission {srv.code}</span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* INTERACTIVE PROJECT SCOPE & INVESTMENT CALCULATOR */}
      <div className="rounded-3xl bg-[#13151A] border-2 border-[#E2FF32]/40 p-6 sm:p-10 space-y-8 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#F4F3EF]/10 pb-6">
          <div>
            <div className="inline-flex items-center gap-2 font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32] mb-2">
              <Calculator className="w-4 h-4" /> INTERACTIVE PROJECT CONFIGURATOR
            </div>
            <h3 className="font-syne font-extrabold text-2xl sm:text-4xl text-[#F4F3EF]">
              Instant Scope &{' '}
              <span className="font-editorial italic font-normal text-[#E2FF32]">
                Investment Telemetry
              </span>
            </h3>
          </div>
          <p className="font-mono-tech text-xs text-[#9A9EA7] max-w-sm">
            Configure your deliverables below to calculate transparent fixed-sprint pricing before
            booking a call.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left 7 Columns: Interactive Controls */}
          <div className="lg:col-span-7 space-y-6">
            {/* Control 1: Core Discipline */}
            <div className="space-y-2.5">
              <label className="block font-mono-tech text-xs uppercase text-[#9A9EA7]">
                01 // PRIMARY DISCIPLINE
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {SERVICES.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSelectedDiscipline(s.id)}
                    className={`p-3.5 rounded-xl text-left border transition-all ${
                      selectedDiscipline === s.id
                        ? 'bg-[#E2FF32]/15 border-[#E2FF32] text-[#F4F3EF]'
                        : 'bg-[#0B0C0E] border-[#F4F3EF]/10 text-[#9A9EA7] hover:text-[#F4F3EF]'
                    }`}
                  >
                    <div className="font-mono-tech text-[10px] text-[#E2FF32]">{s.code}</div>
                    <div className="font-syne font-bold text-sm mt-0.5">{s.title}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Control 2: Number of Views / Modules */}
            <div className="space-y-2.5 p-4 rounded-2xl bg-[#0B0C0E] border border-[#F4F3EF]/10">
              <div className="flex items-center justify-between">
                <label className="font-mono-tech text-xs uppercase text-[#9A9EA7]">
                  02 // NUMBER OF CUSTOM VIEWS / APP MODULES
                </label>
                <span className="font-syne font-extrabold text-xl text-[#E2FF32]">
                  {pageCount} Views
                </span>
              </div>
              <input
                type="range"
                min={1}
                max={15}
                value={pageCount}
                onChange={(e) => setPageCount(Number(e.target.value))}
                className="w-full accent-[#E2FF32] cursor-pointer"
              />
              <div className="flex justify-between font-mono-tech text-[10px] text-[#5E626E]">
                <span>1 Landing Flagship</span>
                <span>5 Core App Views</span>
                <span>15+ Full Platform</span>
              </div>
            </div>

            {/* Control 3: Typography & Motion Craft Level */}
            <div className="space-y-2.5">
              <label className="block font-mono-tech text-xs uppercase text-[#9A9EA7]">
                03 // UNCOMMON TYPOGRAPHY & INTERACTION TIER
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {[
                  {
                    id: 'editorial',
                    name: 'Swiss Editorial',
                    desc: 'Crisp Grid + 60fps CSS Transitions',
                  },
                  {
                    id: 'kinetic',
                    name: 'Kinetic Uncommon',
                    desc: 'Multi-Font Display + Custom Micro-Physics',
                  },
                  {
                    id: 'webgl',
                    name: 'Spatial & WebGL',
                    desc: 'Custom Shaders + 3D Interactive Canvas',
                  },
                ].map((tier) => (
                  <button
                    key={tier.id}
                    type="button"
                    onClick={() => setMotionTier(tier.id as 'editorial' | 'kinetic' | 'webgl')}
                    className={`p-3.5 rounded-xl text-left border transition-all ${
                      motionTier === tier.id
                        ? 'bg-[#F4F3EF] text-[#0B0C0E] border-[#F4F3EF]'
                        : 'bg-[#0B0C0E] border-[#F4F3EF]/10 text-[#9A9EA7]'
                    }`}
                  >
                    <div className="font-syne font-bold text-xs uppercase">{tier.name}</div>
                    <div
                      className={`font-jakarta text-[11px] mt-1 ${
                        motionTier === tier.id ? 'text-[#0B0C0E]/80' : 'text-[#9A9EA7]'
                      }`}
                    >
                      {tier.desc}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Control 4: Technical Add-Ons */}
            <div className="space-y-2.5">
              <label className="block font-mono-tech text-xs uppercase text-[#9A9EA7]">
                04 // ARCHITECTURAL MODULES & INTEGRATIONS
              </label>
              <div className="flex flex-wrap gap-2">
                {[
                  'Uncommon Font System',
                  'Full-Stack API/Auth',
                  'Stripe / Checkout Pipeline',
                  'AI LLM Streaming SDK',
                  'CMS / MDX Blog Engine',
                  'Design Token Storybook',
                ].map((item) => {
                  const active = addons.includes(item);
                  return (
                    <button
                      key={item}
                      type="button"
                      onClick={() => toggleAddon(item)}
                      className={`px-3.5 py-2 rounded-xl font-mono-tech text-xs border transition-all ${
                        active
                          ? 'bg-[#E2FF32]/15 border-[#E2FF32] text-[#E2FF32] font-bold'
                          : 'bg-[#0B0C0E] border-[#F4F3EF]/10 text-[#9A9EA7]'
                      }`}
                    >
                      {active ? '✓ ' : '+ '}
                      {item}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right 5 Columns: Live Output Receipt */}
          <div className="lg:col-span-5 rounded-2xl bg-[#0B0C0E] border border-[#F4F3EF]/15 p-6 sm:p-7 space-y-6">
            <div className="flex items-center justify-between border-b border-[#F4F3EF]/10 pb-4">
              <span className="font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32]">
                MK // LIVE ESTIMATE TELEMETRY
              </span>
              <span className="font-mono-tech text-xs text-[#10B981]">FIXED-SCOPE SPRINT</span>
            </div>

            <div className="space-y-1">
              <div className="font-mono-tech text-xs text-[#9A9EA7]">ESTIMATED INVESTMENT</div>
              <div className="font-syne font-extrabold text-4xl sm:text-5xl text-[#F4F3EF]">
                ${estimatedTotal.toLocaleString()}{' '}
                <span className="font-mono-tech text-sm font-normal text-[#E2FF32]">USD</span>
              </div>
              <div className="font-mono-tech text-xs text-[#9A9EA7] pt-1">
                Estimated Delivery Cadence:{' '}
                <strong className="text-[#F4F3EF]">{estimatedWeeks} Weeks</strong>
              </div>
            </div>

            <div className="space-y-2.5 pt-4 border-t border-[#F4F3EF]/10 font-mono-tech text-xs">
              <div className="flex justify-between text-[#9A9EA7]">
                <span>Base ({baseService.code}):</span>
                <span className="text-[#F4F3EF]">${baseService.startingAtUSD.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[#9A9EA7]">
                <span>Scope ({pageCount} Views/Modules):</span>
                <span className="text-[#F4F3EF]">+${pagesCost.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[#9A9EA7]">
                <span>Interaction Tier ({motionTier.toUpperCase()}):</span>
                <span className="text-[#F4F3EF]">+${motionCost.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-[#9A9EA7]">
                <span>Integrations ({addons.length} selected):</span>
                <span className="text-[#F4F3EF]">+${addonsCost.toLocaleString()}</span>
              </div>
            </div>

            <button
              onClick={() =>
                onOpenBooking(
                  `Custom Configured Scope: ${baseService.title} | ${pageCount} Views | ${motionTier.toUpperCase()} Tier | Addons: ${addons.join(
                    ', '
                  )} | Est: $${estimatedTotal.toLocaleString()}`
                )
              }
              className="w-full py-4 rounded-full bg-[#E2FF32] hover:bg-[#ebff66] text-[#0B0C0E] font-syne font-extrabold text-xs sm:text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_24px_rgba(226,255,50,0.25)] transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span>Lock This Custom Scope with MK</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4-PHASE EXECUTION BLUEPRINT */}
      <div className="space-y-8">
        <div className="border-b border-[#F4F3EF]/10 pb-6">
          <div className="font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32] mb-2">
            HOW FREELANCER MK OPERATES
          </div>
          <h3 className="font-syne font-extrabold text-2xl sm:text-4xl text-[#F4F3EF]">
            Deterministic 4-Stage{' '}
            <span className="font-editorial italic font-normal text-[#E2FF32]">
              Sprint Architecture
            </span>
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {[
            {
              step: 'PHASE // 01',
              title: 'Discovery & Uncommon Type Direction',
              days: 'Days 1 – 3',
              icon: Layers,
              desc: 'We align on conversion KPIs, establish your uncommon display font pairing, and map user flows with zero fluff.',
            },
            {
              step: 'PHASE // 02',
              title: 'High-Craft Interactive Prototyping',
              days: 'Days 4 – 9',
              icon: Sparkles,
              desc: 'High-contrast dark/light Figma architecture and playable layout specimens so you feel the product rhythm early.',
            },
            {
              step: 'PHASE // 03',
              title: 'Full-Stack Production Engineering',
              days: 'Days 10 – 20',
              icon: Cpu,
              desc: 'Clean React 19 / Next.js 15 + TypeScript code, edge API integration, 60fps micro-interactions, and daily staging previews.',
            },
            {
              step: 'PHASE // 04',
              title: '100-Lighthouse Launch & Telemetry',
              days: 'Final 48 Hours',
              icon: Rocket,
              desc: 'Core Web Vitals verification, SEO schema setup, zero-downtime edge deployment, and full repository handoff.',
            },
          ].map((p) => {
            const IconComponent = p.icon;
            return (
              <div
                key={p.step}
                className="p-6 rounded-3xl bg-[#13151A] border border-[#F4F3EF]/10 flex flex-col justify-between gap-6"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="font-mono-tech text-xs text-[#E2FF32] font-bold">
                      {p.step}
                    </span>
                    <IconComponent className="w-5 h-5 text-[#9A9EA7]" />
                  </div>
                  <h4 className="font-syne font-bold text-lg text-[#F4F3EF]">{p.title}</h4>
                  <p className="font-jakarta text-xs sm:text-sm text-[#9A9EA7] leading-relaxed">
                    {p.desc}
                  </p>
                </div>
                <div className="pt-3 border-t border-[#F4F3EF]/10 font-mono-tech text-xs text-[#10B981] flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5" />
                  <span>{p.days}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
