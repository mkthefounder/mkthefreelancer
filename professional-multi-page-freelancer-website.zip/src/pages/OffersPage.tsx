import React, { useState } from 'react';
import { FLASH_OFFERS, FrontTextStyle, OFFER_TIERS } from '../data/mkData';
import { UncommonHeadline } from '../components/UncommonHeadline';
import {
  ArrowUpRight,
  Check,
  Clock,
  Flame,
  ShieldCheck,
  Sparkles,
  Zap,
} from 'lucide-react';

interface OffersPageProps {
  frontTextStyle: FrontTextStyle;
  onOpenBooking: (presetContext?: string) => void;
}

type Currency = 'USD' | 'EUR' | 'GBP';

const CURRENCY_CONFIG: Record<Currency, { symbol: string; rate: number }> = {
  USD: { symbol: '$', rate: 1 },
  EUR: { symbol: '€', rate: 0.92 },
  GBP: { symbol: '£', rate: 0.79 },
};

export const OffersPage: React.FC<OffersPageProps> = ({
  frontTextStyle,
  onOpenBooking,
}) => {
  const [currency, setCurrency] = useState<Currency>('USD');
  const [partnerDiscount, setPartnerDiscount] = useState<boolean>(false);

  const formatMoney = (usd: number) => {
    if (usd === 0) return 'FREE';
    const converted = Math.round(usd * CURRENCY_CONFIG[currency].rate);
    return `${CURRENCY_CONFIG[currency].symbol}${converted.toLocaleString()}`;
  };

  return (
    <div className="px-4 sm:px-8 max-w-[1440px] mx-auto pt-8 sm:pt-12 pb-24 space-y-20">
      {/* Header + Interactive Currency & Cadence Controls */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 border-b border-[#F4F3EF]/10 pb-8">
        <div className="space-y-4 max-w-3xl">
          <UncommonHeadline
            kicker="PAGE 04 // PRODUCTIZED PACKAGES, RETAINERS & FLASH OFFERS"
            primaryText="TRANSPARENT"
            editorialAccent="high-velocity"
            secondaryText="OFFERS & SPRINTS"
            frontTextStyle={frontTextStyle}
            size="banner"
          />
          <p className="font-jakarta text-base sm:text-lg text-[#9A9EA7] leading-relaxed">
            Zero hourly billing surprises. Lock in a deterministic sprint, claim a limited-slot
            founder flash offer, or embed Freelancer MK as your fractional principal partner.
          </p>
        </div>

        {/* Interactive Currency & Quarterly Toggle */}
        <div className="flex flex-wrap items-center gap-3 self-start lg:self-end">
          {/* Currency Pills */}
          <div className="flex items-center p-1 rounded-xl bg-[#13151A] border border-[#F4F3EF]/12">
            {(['USD', 'EUR', 'GBP'] as Currency[]).map((curr) => (
              <button
                key={curr}
                onClick={() => setCurrency(curr)}
                className={`px-3 py-1.5 rounded-lg font-mono-tech text-xs transition-all ${
                  currency === curr
                    ? 'bg-[#F4F3EF] text-[#0B0C0E] font-bold'
                    : 'text-[#9A9EA7] hover:text-[#F4F3EF]'
                }`}
              >
                {curr} ({CURRENCY_CONFIG[curr].symbol})
              </button>
            ))}
          </div>

          {/* Partner Mode Toggle */}
          <button
            onClick={() => setPartnerDiscount((prev) => !prev)}
            className={`px-4 py-2.5 rounded-xl font-mono-tech text-xs border transition-all flex items-center gap-2 ${
              partnerDiscount
                ? 'bg-[#E2FF32]/15 border-[#E2FF32] text-[#E2FF32] font-bold'
                : 'bg-[#13151A] border-[#F4F3EF]/15 text-[#9A9EA7]'
            }`}
          >
            <span>Quarterly Partner (-15%)</span>
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                partnerDiscount ? 'bg-[#E2FF32]' : 'bg-[#5E626E]'
              }`}
            />
          </button>
        </div>
      </div>

      {/* 3-COLUMN PRODUCTIZED RETAINER & SPRINT MATRIX */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-7 items-stretch">
        {OFFER_TIERS.map((tier) => {
          const activePriceUSD = partnerDiscount ? tier.retainerPriceUSD : tier.sprintPriceUSD;
          return (
            <div
              key={tier.id}
              className={`rounded-3xl p-7 sm:p-8 flex flex-col justify-between gap-8 relative transition-all duration-300 ${
                tier.highlighted
                  ? 'bg-[#151821] border-2 border-[#E2FF32] shadow-[0_0_45px_rgba(226,255,50,0.12)] lg:-translate-y-2'
                  : 'bg-[#13151A] border border-[#F4F3EF]/12 hover:border-[#F4F3EF]/30'
              }`}
            >
              {tier.badge && (
                <div className="absolute -top-3.5 left-7 px-3.5 py-1 rounded-full bg-[#E2FF32] text-[#0B0C0E] font-mono-tech text-[10px] font-bold uppercase tracking-wider">
                  ★ {tier.badge}
                </div>
              )}

              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <span className="font-mono-tech text-xs text-[#E2FF32] font-bold">
                    {tier.code}
                  </span>
                  <span className="font-mono-tech text-[11px] px-2.5 py-1 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">
                    ● {tier.capacityStatus}
                  </span>
                </div>

                <div>
                  <h2 className="font-syne font-extrabold text-2xl text-[#F4F3EF]">
                    {tier.name}
                  </h2>
                  <p className="font-editorial italic text-xl text-[#9A9EA7] mt-1">
                    {tier.tagline}
                  </p>
                </div>

                {/* Price Block */}
                <div className="p-4 rounded-2xl bg-[#0B0C0E] border border-[#F4F3EF]/10">
                  <div className="flex items-baseline gap-2">
                    <span className="font-syne font-extrabold text-4xl text-[#F4F3EF]">
                      {formatMoney(activePriceUSD)}
                    </span>
                    {partnerDiscount && (
                      <span className="font-mono-tech text-xs line-through text-[#5E626E]">
                        {formatMoney(tier.sprintPriceUSD)}
                      </span>
                    )}
                  </div>
                  <div className="font-mono-tech text-[11px] text-[#E2FF32] mt-1">
                    {tier.durationLabel} {partnerDiscount && '• 15% Partner Rate Applied'}
                  </div>
                </div>

                <p className="font-jakarta text-sm text-[#9A9EA7] leading-relaxed">
                  {tier.description}
                </p>

                {/* Features List */}
                <div className="space-y-2.5 pt-2">
                  <div className="font-mono-tech text-[10px] uppercase tracking-widest text-[#9A9EA7]">
                    WHAT’S INCLUDED:
                  </div>
                  <ul className="space-y-2.5">
                    {tier.features.map((feat) => (
                      <li
                        key={feat}
                        className="flex items-start gap-2.5 font-jakarta text-xs sm:text-sm text-[#F4F3EF]"
                      >
                        <Check className="w-4 h-4 text-[#E2FF32] shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Guarantees & CTA */}
              <div className="space-y-4 pt-5 border-t border-[#F4F3EF]/10">
                <div className="space-y-1.5">
                  {tier.guarantees.map((g) => (
                    <div
                      key={g}
                      className="flex items-center gap-2 font-mono-tech text-[11px] text-[#10B981]"
                    >
                      <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                      <span>{g}</span>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() =>
                    onOpenBooking(
                      `${tier.name} (${formatMoney(activePriceUSD)} - ${tier.durationLabel})`
                    )
                  }
                  className={`w-full py-4 rounded-full font-syne font-extrabold text-xs sm:text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all ${
                    tier.highlighted
                      ? 'bg-[#E2FF32] hover:bg-[#ebff66] text-[#0B0C0E] shadow-[0_0_28px_rgba(226,255,50,0.3)]'
                      : 'bg-[#F4F3EF] hover:bg-[#E2FF32] text-[#0B0C0E]'
                  }`}
                >
                  <span>{tier.ctaLabel}</span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* SPECIAL FLASH OFFERS & RAPID MICRO-SPRINTS */}
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#F4F3EF]/10 pb-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FF4D2D]/20 border border-[#FF4D2D]/40 font-mono-tech text-xs text-[#FF4D2D] font-bold mb-3">
              <Flame className="w-3.5 h-3.5" /> SPECIAL LIMITED-SLOT FLASH OFFERS
            </div>
            <h3 className="font-syne font-extrabold text-2xl sm:text-4xl text-[#F4F3EF]">
              Rapid Micro-Sprints &{' '}
              <span className="font-editorial italic font-normal text-[#E2FF32]">
                First-Engagement Deals
              </span>
            </h3>
          </div>
          <p className="font-mono-tech text-xs text-[#9A9EA7] max-w-sm">
            Ideal for testing Moin Uddin Khan’s speed and typographic craft on a focused deliverable
            in 48 to 120 hours.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {FLASH_OFFERS.map((offer) => (
            <div
              key={offer.id}
              className="rounded-3xl bg-[#13151A] border border-[#F4F3EF]/12 hover:border-[#FF4D2D] p-6 sm:p-8 flex flex-col justify-between gap-6 transition-all shadow-xl"
            >
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-mono-tech text-xs px-2.5 py-1 rounded bg-[#FF4D2D]/20 text-[#FF4D2D] border border-[#FF4D2D]/40 font-bold">
                    {offer.discountBadge}
                  </span>
                  <div className="flex items-center gap-3 font-mono-tech text-xs text-[#9A9EA7]">
                    <span className="flex items-center gap-1 text-[#E2FF32]">
                      <Clock className="w-3.5 h-3.5" /> {offer.turnaround}
                    </span>
                    <span>• {offer.slotsRemaining} Slots Left</span>
                  </div>
                </div>

                <div>
                  <h4 className="font-syne font-extrabold text-xl sm:text-2xl text-[#F4F3EF]">
                    {offer.title}
                  </h4>
                  <p className="font-editorial italic text-xl text-[#E2FF32] mt-1">
                    {offer.subtitle}
                  </p>
                </div>

                <p className="font-jakarta text-xs sm:text-sm text-[#9A9EA7] leading-relaxed">
                  {offer.description}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  {offer.includes.map((inc) => (
                    <div
                      key={inc}
                      className="p-2.5 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/8 font-jakarta text-xs text-[#F4F3EF] flex items-start gap-2"
                    >
                      <Zap className="w-3.5 h-3.5 text-[#E2FF32] shrink-0 mt-0.5" />
                      <span>{inc}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-[#F4F3EF]/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-baseline gap-2.5">
                  <span className="font-syne font-extrabold text-3xl text-[#E2FF32]">
                    {formatMoney(offer.offerUSD)}
                  </span>
                  <span className="font-mono-tech text-sm line-through text-[#5E626E]">
                    {formatMoney(offer.originalUSD)}
                  </span>
                  <span className="font-mono-tech text-[10px] uppercase text-[#9A9EA7]">
                    FIXED TOTAL
                  </span>
                </div>

                <button
                  onClick={() =>
                    onOpenBooking(
                      `Claiming Flash Offer: ${offer.title} (${formatMoney(offer.offerUSD)})`
                    )
                  }
                  className="px-6 py-3 rounded-full bg-[#E2FF32] hover:bg-[#ebff66] text-[#0B0C0E] font-syne font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Claim This Offer</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* WHY FREELANCER MK VS AGENCY VS FULL-TIME HIRE COMPARISON MATRIX */}
      <div className="rounded-3xl bg-[#13151A] border border-[#F4F3EF]/15 p-6 sm:p-10 space-y-6">
        <div className="space-y-2">
          <div className="font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32]">
            VALUE ARCHITECTURE BENCHMARK
          </div>
          <h3 className="font-syne font-extrabold text-2xl sm:text-3xl text-[#F4F3EF]">
            Why Technical Founders Choose{' '}
            <span className="font-editorial italic font-normal text-[#E2FF32]">
              Moin Uddin Khan (Freelancer MK)
            </span>
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse font-jakarta text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-[#F4F3EF]/15 font-mono-tech text-xs uppercase text-[#9A9EA7]">
                <th className="py-4 px-4">Criterion</th>
                <th className="py-4 px-4 bg-[#E2FF32]/10 text-[#E2FF32] rounded-t-xl border-x border-t border-[#E2FF32]/30">
                  Moin Uddin Khan (Freelancer MK)
                </th>
                <th className="py-4 px-4">Traditional Agency</th>
                <th className="py-4 px-4">Full-Time Senior Hire</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F4F3EF]/10">
              {[
                {
                  metric: 'Time to First Production Commit',
                  mk: 'Within 48 Hours',
                  agency: '3 – 5 Weeks (Discovery Bloat)',
                  hire: '2 – 4 Months Recruiting',
                },
                {
                  metric: 'Who Actually Does the Work?',
                  mk: '100% Principal MK (Design + Code)',
                  agency: 'Handed Off to Junior Subcontractors',
                  hire: 'Single Discipline (Usually UI or Dev Only)',
                },
                {
                  metric: 'Uncommon Typography & Visual Craft',
                  mk: 'Bespoke Editorial + Kinetic Systems',
                  agency: 'Cookie-Cutter Agency Playbook',
                  hire: 'Rarely Trained in Editorial Direction',
                },
                {
                  metric: 'Full-Stack Production Engineering',
                  mk: 'Next.js 15, TypeScript, Edge, 100 LH',
                  agency: 'Often Outsourced or Webflow-Only',
                  hire: 'Strong Code, Weak Visual Polish',
                },
                {
                  metric: 'Typical Investment Cost',
                  mk: '$950 – $5,800 Fixed & Predictable',
                  agency: '$25,000 – $65,000+ Retainers',
                  hire: '$165,000+/yr + Equity + Benefits',
                },
              ].map((row) => (
                <tr key={row.metric}>
                  <td className="py-4 px-4 font-semibold text-[#F4F3EF]">{row.metric}</td>
                  <td className="py-4 px-4 bg-[#E2FF32]/10 text-[#F4F3EF] font-bold border-x border-[#E2FF32]/30">
                    ✓ {row.mk}
                  </td>
                  <td className="py-4 px-4 text-[#9A9EA7]">{row.agency}</td>
                  <td className="py-4 px-4 text-[#9A9EA7]">{row.hire}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
