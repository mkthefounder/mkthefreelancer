import React, { useState } from 'react';
import { FrontTextStyle, REVIEWS, ReviewItem } from '../data/mkData';
import { UncommonHeadline } from '../components/UncommonHeadline';
import {
  Award,
  CheckCircle2,
  MessageSquarePlus,
  Quote,
  ShieldCheck,
  Sparkles,
  Star,
} from 'lucide-react';

interface ReviewsPageProps {
  frontTextStyle: FrontTextStyle;
  onOpenBooking: (presetContext?: string) => void;
}

const REVIEW_CATEGORIES = ['All', 'Fintech', 'E-Commerce', 'SaaS & AI', 'Design Systems'] as const;

export const ReviewsPage: React.FC<ReviewsPageProps> = ({
  frontTextStyle,
  onOpenBooking,
}) => {
  const [reviewsList, setReviewsList] = useState<ReviewItem[]>(REVIEWS);
  const [activeFilter, setActiveFilter] = useState<string>('All');
  const [showAddForm, setShowAddForm] = useState<boolean>(false);

  // New Review Form State
  const [authorName, setAuthorName] = useState('');
  const [authorRole, setAuthorRole] = useState('');
  const [authorCompany, setAuthorCompany] = useState('');
  const [authorLocation, setAuthorLocation] = useState('');
  const [authorCategory, setAuthorCategory] = useState<ReviewItem['category']>('SaaS & AI');
  const [headlineQuote, setHeadlineQuote] = useState('');
  const [fullReview, setFullReview] = useState('');
  const [impactMetric, setImpactMetric] = useState('');

  const filteredReviews =
    activeFilter === 'All'
      ? reviewsList
      : reviewsList.filter((r) => r.category === activeFilter);

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authorName || !headlineQuote) return;

    const newEntry: ReviewItem = {
      id: `rev-custom-${Date.now()}`,
      index: `REV // 0${reviewsList.length + 1}`,
      clientName: authorName,
      role: authorRole || 'Founder',
      company: authorCompany || 'Stealth Venture',
      location: authorLocation || 'Global Remote',
      category: authorCategory,
      rating: 5.0,
      date: 'Just Verified • 2026',
      projectDelivered: 'Bespoke Full-Stack & Typography Sprint',
      verifiedImpact: impactMetric || '+100% Lighthouse & Brand Lift',
      headlineQuote,
      fullReview:
        fullReview ||
        headlineQuote,
      budgetRange: '$3,500 – $7,500',
    };

    setReviewsList([newEntry, ...reviewsList]);
    setAuthorName('');
    setAuthorRole('');
    setAuthorCompany('');
    setAuthorLocation('');
    setHeadlineQuote('');
    setFullReview('');
    setImpactMetric('');
    setShowAddForm(false);
  };

  return (
    <div className="px-4 sm:px-8 max-w-[1440px] mx-auto pt-8 sm:pt-12 pb-24 space-y-16">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 border-b border-[#F4F3EF]/10 pb-8">
        <div className="space-y-4 max-w-3xl">
          <UncommonHeadline
            kicker="PAGE 05 // CLIENT ENDORSEMENT LEDGER"
            primaryText="VERIFIED EXECUTIVE"
            editorialAccent="client reviews"
            secondaryText="& OUTCOME PROOF"
            frontTextStyle={frontTextStyle}
            size="banner"
          />
          <p className="font-jakarta text-base sm:text-lg text-[#9A9EA7] leading-relaxed">
            Unfiltered endorsements from CTOs, Creative Directors, and Venture Founders who partnered
            with Moin Uddin Khan (Freelancer MK) for mission-critical launches.
          </p>
        </div>

        <button
          onClick={() => setShowAddForm((prev) => !prev)}
          className="px-5 py-3.5 rounded-full bg-[#E2FF32] hover:bg-[#ebff66] text-[#0B0C0E] font-syne font-extrabold text-xs uppercase tracking-wider flex items-center gap-2 self-start lg:self-end transition-all"
        >
          <MessageSquarePlus className="w-4 h-4" />
          <span>{showAddForm ? 'Close Submission Form' : 'Submit Client Endorsement'}</span>
        </button>
      </div>

      {/* Aggregate Telemetry Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            score: '4.98 / 5.0',
            label: 'Aggregate Verified Score',
            sub: 'Across 64+ Delivered Sprints',
          },
          {
            score: '94%',
            label: 'Repeat Partner Retention',
            sub: 'Founders Hiring MK for Phase 2+',
          },
          {
            score: '100%',
            label: 'On-Schedule Delivery SLA',
            sub: 'Deterministic Milestone Commits',
          },
          {
            score: '3.4x',
            label: 'Avg. Conversion Lift',
            sub: 'Post-Launch Telemetry Benchmark',
          },
        ].map((item) => (
          <div
            key={item.label}
            className="p-6 rounded-3xl bg-[#13151A] border border-[#F4F3EF]/12 space-y-1.5"
          >
            <div className="flex items-center justify-between">
              <span className="font-syne font-extrabold text-3xl sm:text-4xl text-[#E2FF32]">
                {item.score}
              </span>
              <ShieldCheck className="w-5 h-5 text-[#10B981]" />
            </div>
            <div className="font-syne font-bold text-sm text-[#F4F3EF]">{item.label}</div>
            <div className="font-mono-tech text-[11px] text-[#9A9EA7]">{item.sub}</div>
          </div>
        ))}
      </div>

      {/* Interactive Add Review Form Drawer */}
      {showAddForm && (
        <form
          onSubmit={handleAddReview}
          className="rounded-3xl bg-[#13151A] border-2 border-[#E2FF32] p-6 sm:p-9 space-y-6 shadow-2xl"
        >
          <div className="flex items-center justify-between border-b border-[#F4F3EF]/10 pb-4">
            <div>
              <span className="font-mono-tech text-xs text-[#E2FF32] uppercase">
                LIVE ENDORSEMENT DISPATCH
              </span>
              <h3 className="font-syne font-extrabold text-2xl text-[#F4F3EF]">
                Publish a Client Review for Moin Uddin Khan (Freelancer MK)
              </h3>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1">
                Your Name *
              </label>
              <input
                type="text"
                required
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                placeholder="David Sterling"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 text-sm text-[#F4F3EF]"
              />
            </div>
            <div>
              <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1">
                Role / Title
              </label>
              <input
                type="text"
                value={authorRole}
                onChange={(e) => setAuthorRole(e.target.value)}
                placeholder="Founder & CEO"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 text-sm text-[#F4F3EF]"
              />
            </div>
            <div>
              <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1">
                Company
              </label>
              <input
                type="text"
                value={authorCompany}
                onChange={(e) => setAuthorCompany(e.target.value)}
                placeholder="Apex Neural"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 text-sm text-[#F4F3EF]"
              />
            </div>
            <div>
              <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1">
                Sector
              </label>
              <select
                value={authorCategory}
                onChange={(e) => setAuthorCategory(e.target.value as ReviewItem['category'])}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 text-sm text-[#F4F3EF]"
              >
                <option value="SaaS & AI">SaaS & AI</option>
                <option value="Fintech">Fintech</option>
                <option value="E-Commerce">E-Commerce</option>
                <option value="Design Systems">Design Systems</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1">
                Headline Pull-Quote *
              </label>
              <input
                type="text"
                required
                value={headlineQuote}
                onChange={(e) => setHeadlineQuote(e.target.value)}
                placeholder="Moin transformed our product into a category-defining flagship..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 text-sm text-[#F4F3EF]"
              />
            </div>
            <div>
              <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1">
                Key Measurable Result (Optional)
              </label>
              <input
                type="text"
                value={impactMetric}
                onChange={(e) => setImpactMetric(e.target.value)}
                placeholder="+85% Conversion Lift & 100 Lighthouse"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 text-sm text-[#F4F3EF]"
              />
            </div>
          </div>

          <div>
            <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1">
              Full Endorsement Details
            </label>
            <textarea
              rows={3}
              value={fullReview}
              onChange={(e) => setFullReview(e.target.value)}
              placeholder="Share your experience working with Moin Uddin Khan on typography, design systems, and engineering speed..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 text-sm text-[#F4F3EF]"
            />
          </div>

          <button
            type="submit"
            className="px-6 py-3 rounded-full bg-[#E2FF32] text-[#0B0C0E] font-syne font-extrabold text-xs uppercase tracking-wider"
          >
            Publish Verified Endorsement to Ledger
          </button>
        </form>
      )}

      {/* Filter Bar */}
      <div className="flex flex-wrap items-center gap-2">
        {REVIEW_CATEGORIES.map((cat) => {
          const active = activeFilter === cat;
          return (
            <button
              key={cat}
              onClick={() => setActiveFilter(cat)}
              className={`px-4 py-2 rounded-full font-mono-tech text-xs border transition-all ${
                active
                  ? 'bg-[#F4F3EF] text-[#0B0C0E] border-[#F4F3EF] font-bold'
                  : 'bg-[#13151A] text-[#9A9EA7] border-[#F4F3EF]/12 hover:text-[#F4F3EF]'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Reviews Editorial Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-7">
        {filteredReviews.map((rev) => (
          <div
            key={rev.id}
            className="rounded-3xl bg-[#13151A] border border-[#F4F3EF]/12 hover:border-[#E2FF32]/50 p-7 sm:p-9 flex flex-col justify-between gap-7 relative transition-all shadow-xl"
          >
            <Quote className="w-10 h-10 text-[#E2FF32]/15 absolute top-6 right-6 pointer-events-none" />

            <div className="space-y-5">
              {/* Top Verification Row */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="font-mono-tech text-xs text-[#E2FF32] font-bold">
                    [{rev.index}]
                  </span>
                  <span className="font-mono-tech text-xs px-2.5 py-0.5 rounded-full bg-[#0B0C0E] border border-[#F4F3EF]/12 text-[#F4F3EF]">
                    {rev.category}
                  </span>
                </div>
                <div className="flex items-center gap-1 text-[#E2FF32]">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-[#E2FF32]" />
                  ))}
                  <span className="font-mono-tech text-xs font-bold text-[#F4F3EF] ml-1">
                    {rev.rating.toFixed(1)}
                  </span>
                </div>
              </div>

              {/* Monumental Editorial Serif Pull-Quote */}
              <blockquote className="font-editorial italic text-2xl sm:text-3xl text-[#F4F3EF] leading-snug">
                “{rev.headlineQuote}”
              </blockquote>

              {/* Full Narrative */}
              <p className="font-jakarta text-sm sm:text-base text-[#9A9EA7] leading-relaxed">
                {rev.fullReview}
              </p>

              {/* Verified Impact Pill */}
              <div className="p-3.5 rounded-2xl bg-[#0B0C0E] border border-[#10B981]/30 flex flex-wrap items-center justify-between gap-2">
                <span className="font-mono-tech text-xs text-[#10B981] font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> OUTCOME: {rev.verifiedImpact}
                </span>
                <span className="font-mono-tech text-[11px] text-[#9A9EA7]">
                  Scope: {rev.budgetRange}
                </span>
              </div>
            </div>

            {/* Client Signature Footer */}
            <div className="pt-5 border-t border-[#F4F3EF]/10 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-[#0B0C0E] border border-[#E2FF32]/40 flex items-center justify-center font-syne font-extrabold text-sm text-[#E2FF32]">
                  {rev.clientName
                    .split(' ')
                    .map((n) => n[0])
                    .join('')}
                </div>
                <div>
                  <div className="font-syne font-bold text-base text-[#F4F3EF]">
                    {rev.clientName}
                  </div>
                  <div className="font-mono-tech text-xs text-[#9A9EA7]">
                    {rev.role}, <span className="text-[#F4F3EF]">{rev.company}</span> •{' '}
                    {rev.location}
                  </div>
                </div>
              </div>

              <span className="font-mono-tech text-[11px] text-[#5E626E] hidden sm:inline">
                {rev.date}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom CTA Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-[#E2FF32]/15 via-[#13151A] to-[#FF4D2D]/15 border border-[#E2FF32]/40 p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center md:text-left">
          <div className="font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32] flex items-center justify-center md:justify-start gap-2">
            <Award className="w-4 h-4" /> READY TO BE THE NEXT VERIFIED CASE STUDY?
          </div>
          <h3 className="font-syne font-extrabold text-2xl sm:text-3xl text-[#F4F3EF]">
            Partner Directly With Moin Uddin Khan (Freelancer MK)
          </h3>
        </div>
        <button
          onClick={() => onOpenBooking('Initiating Project from Client Reviews Page')}
          className="px-7 py-4 rounded-full bg-[#E2FF32] hover:bg-[#ebff66] text-[#0B0C0E] font-syne font-extrabold text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2 shrink-0"
        >
          <Sparkles className="w-4 h-4" />
          <span>Book Discovery or Lock Sprint</span>
        </button>
      </div>
    </div>
  );
};
