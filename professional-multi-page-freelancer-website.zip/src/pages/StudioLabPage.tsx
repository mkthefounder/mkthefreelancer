import React, { useState, useEffect } from 'react';
import {
  FAQS,
  FrontTextStyle,
  MK_PROFILE,
  TYPOGRAPHY_SPECIMENS,
} from '../data/mkData';
import { UncommonHeadline } from '../components/UncommonHeadline';
import {
  ChevronDown,
  Clock,
  Code2,
  Compass,
  Globe,
  Sliders,
  Sparkles,
  Terminal,
  Type,
} from 'lucide-react';

interface StudioLabPageProps {
  frontTextStyle: FrontTextStyle;
  onChangeFrontTextStyle: (style: FrontTextStyle) => void;
  onOpenBooking: (presetContext?: string) => void;
}

export const StudioLabPage: React.FC<StudioLabPageProps> = ({
  frontTextStyle,
  onChangeFrontTextStyle,
  onOpenBooking,
}) => {
  // Interactive Type Playground State
  const [customPrimary, setCustomPrimary] = useState('MOIN UDDIN KHAN');
  const [customAccent, setCustomAccent] = useState('uncommon digital craft');
  const [customSub, setCustomSub] = useState('FREELANCER MK // FULL-STACK ARCHITECT');
  const [playgroundFont, setPlaygroundFont] = useState<'syne' | 'editorial' | 'fraunces' | 'stroke'>('syne');
  const [trackingTight, setTrackingTight] = useState<number>(-3);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [currentTime, setCurrentTime] = useState<string>('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setCurrentTime(
        now.toUTCString().replace('GMT', 'UTC')
      );
    };
    updateClock();
    const timer = setInterval(updateClock, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="px-4 sm:px-8 max-w-[1440px] mx-auto pt-8 sm:pt-12 pb-24 space-y-20">
      {/* Header */}
      <div className="border-b border-[#F4F3EF]/10 pb-8 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
        <div className="space-y-4 max-w-3xl">
          <UncommonHeadline
            kicker="PAGE 06 // UNCOMMON FRONT-TEXT LAB, STUDIO BIO & OTHERS"
            primaryText="THE TYPOGRAPHIC"
            editorialAccent="laboratory &"
            secondaryText="MK MANIFESTO"
            frontTextStyle={frontTextStyle}
            size="banner"
          />
          <p className="font-jakarta text-base sm:text-lg text-[#9A9EA7] leading-relaxed">
            Explore Moin Uddin Khan’s signature uncommon front-text typography engine, test custom
            headlines for your own brand, and inspect the operational ethos behind Freelancer MK.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-[#13151A] border border-[#F4F3EF]/12 font-mono-tech text-xs space-y-1">
          <div className="flex items-center gap-2 text-[#E2FF32]">
            <Clock className="w-3.5 h-3.5" />
            <span>STUDIO TELEMETRY CLOCK</span>
          </div>
          <div className="text-[#F4F3EF]">{currentTime || 'SYNCING UTC...'}</div>
        </div>
      </div>

      {/* INTERACTIVE UNCOMMON FRONT-TEXT PLAYGROUND */}
      <section className="rounded-3xl bg-[#13151A] border-2 border-[#E2FF32]/45 p-6 sm:p-10 space-y-8 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#F4F3EF]/10 pb-6">
          <div>
            <div className="inline-flex items-center gap-2 font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32] mb-1.5">
              <Type className="w-4 h-4" /> INTERACTIVE UNCOMMON FRONT-TEXT SPECIMEN LAB
            </div>
            <h2 className="font-syne font-extrabold text-2xl sm:text-4xl text-[#F4F3EF]">
              Test & Customize{' '}
              <span className="font-editorial italic font-normal text-[#E2FF32]">
                Uncommon Display Typography
              </span>
            </h2>
          </div>

          <div className="flex flex-wrap gap-2">
            {(
              [
                { id: 'hybrid', label: 'Site Mode: Hybrid' },
                { id: 'brutalist', label: 'Site Mode: Brutalist' },
                { id: 'couture', label: 'Site Mode: Couture' },
                { id: 'outlined', label: 'Site Mode: Outlined' },
              ] as { id: FrontTextStyle; label: string }[]
            ).map((m) => (
              <button
                key={m.id}
                onClick={() => onChangeFrontTextStyle(m.id)}
                className={`px-3 py-1.5 rounded-xl font-mono-tech text-xs border transition-all ${
                  frontTextStyle === m.id
                    ? 'bg-[#E2FF32] text-[#0B0C0E] border-[#E2FF32] font-bold'
                    : 'bg-[#0B0C0E] text-[#9A9EA7] border-[#F4F3EF]/10 hover:text-[#F4F3EF]'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {/* Live Specimen Stage */}
        <div className="rounded-2xl bg-[#0B0C0E] border border-[#F4F3EF]/15 p-8 sm:p-12 relative overflow-hidden bg-arch-grid">
          <div className="relative z-10 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#13151A] border border-[#E2FF32]/30 font-mono-tech text-xs text-[#E2FF32]">
              <span>● {customSub || 'LIVE SPECIMEN'}</span>
            </div>

            <div
              style={{ letterSpacing: `${trackingTight * 0.01}em` }}
              className="text-[clamp(2.2rem,5.8vw,5.1rem)] leading-[0.95] transition-all"
            >
              {playgroundFont === 'syne' && (
                <div>
                  <span className="font-syne font-extrabold uppercase text-[#F4F3EF]">
                    {customPrimary}{' '}
                  </span>
                  <span className="font-editorial italic text-[#E2FF32] font-normal">
                    {customAccent}
                  </span>
                </div>
              )}

              {playgroundFont === 'editorial' && (
                <div>
                  <span className="font-editorial text-[#F4F3EF]">{customPrimary} — </span>
                  <span className="font-syne font-extrabold uppercase text-[#FF4D2D]">
                    {customAccent}
                  </span>
                </div>
              )}

              {playgroundFont === 'fraunces' && (
                <div>
                  <span className="font-fraunces font-bold text-[#F4F3EF]">{customPrimary} </span>
                  <span className="font-fraunces italic text-[#E2FF32] underline decoration-[#FF4D2D] decoration-2 underline-offset-8">
                    {customAccent}
                  </span>
                </div>
              )}

              {playgroundFont === 'stroke' && (
                <div>
                  <span className="font-syne font-extrabold uppercase text-stroke-strong">
                    {customPrimary}{' '}
                  </span>
                  <span className="font-syne font-extrabold uppercase text-[#E2FF32]">
                    {customAccent}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Interactive Controls for the Specimen */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1.5">
              Type Custom Primary Headline
            </label>
            <input
              type="text"
              value={customPrimary}
              onChange={(e) => setCustomPrimary(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 text-sm text-[#F4F3EF] focus:border-[#E2FF32] focus:outline-none"
            />
          </div>

          <div>
            <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1.5">
              Type Editorial Counterpoint Text
            </label>
            <input
              type="text"
              value={customAccent}
              onChange={(e) => setCustomAccent(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 text-sm text-[#E2FF32] focus:border-[#E2FF32] focus:outline-none"
            />
          </div>

          <div>
            <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1.5">
              Type Monospace Telemetry Kicker
            </label>
            <input
              type="text"
              value={customSub}
              onChange={(e) => setCustomSub(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 font-mono-tech text-xs text-[#F4F3EF] focus:border-[#E2FF32] focus:outline-none"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-mono-tech text-xs text-[#9A9EA7] flex items-center gap-1">
              <Sliders className="w-3.5 h-3.5 text-[#E2FF32]" /> PAIRING ENGINE:
            </span>
            {[
              { id: 'syne', label: 'Syne 800 + Instrument Serif' },
              { id: 'editorial', label: 'Editorial Monograph + Brutalist' },
              { id: 'fraunces', label: 'Fraunces Variable Optical' },
              { id: 'stroke', label: 'Hollow Vector Wireframe' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() =>
                  setPlaygroundFont(f.id as 'syne' | 'editorial' | 'fraunces' | 'stroke')
                }
                className={`px-3.5 py-2 rounded-xl font-mono-tech text-xs border transition-all ${
                  playgroundFont === f.id
                    ? 'bg-[#F4F3EF] text-[#0B0C0E] border-[#F4F3EF] font-bold'
                    : 'bg-[#0B0C0E] text-[#9A9EA7] border-[#F4F3EF]/12'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <span className="font-mono-tech text-xs text-[#9A9EA7]">TRACKING:</span>
            <input
              type="range"
              min={-6}
              max={6}
              value={trackingTight}
              onChange={(e) => setTrackingTight(Number(e.target.value))}
              className="w-28 accent-[#E2FF32]"
            />
          </div>
        </div>

        {/* 3 Preset Uncommon Specimen Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-[#F4F3EF]/10">
          {TYPOGRAPHY_SPECIMENS.map((spec) => (
            <div
              key={spec.id}
              onClick={() => {
                setCustomPrimary(spec.samplePrimary);
                setCustomAccent(spec.sampleAccent);
                setCustomSub(spec.sampleSub);
              }}
              className="cursor-pointer p-4 rounded-2xl bg-[#0B0C0E] border border-[#F4F3EF]/10 hover:border-[#E2FF32] transition-all space-y-2"
            >
              <div className="font-mono-tech text-[11px] text-[#E2FF32] font-bold">
                {spec.name}
              </div>
              <div className="font-mono-tech text-[10px] text-[#9A9EA7]">{spec.fontsUsed}</div>
              <p className="font-jakarta text-xs text-[#F4F3EF]/85">{spec.character}</p>
              <div className="font-mono-tech text-[10px] text-[#E2FF32] pt-1">
                CLICK TO LOAD INTO STAGE ↑
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* MOIN UDDIN KHAN (FREELANCER MK) BIOGRAPHY & ARCHITECTURAL CREDENTIALS */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left 7 Columns: Biography & Philosophy */}
        <div className="lg:col-span-7 rounded-3xl bg-[#13151A] border border-[#F4F3EF]/12 p-7 sm:p-10 space-y-6">
          <div className="inline-flex items-center gap-2 font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32]">
            <Compass className="w-4 h-4" /> THE ARCHITECT BEHIND FREELANCER MK
          </div>

          <h3 className="font-syne font-extrabold text-3xl sm:text-4xl text-[#F4F3EF]">
            Moin Uddin Khan —{' '}
            <span className="font-editorial italic font-normal text-[#E2FF32]">
              Bridging the Chasm Between Art Direction & Systems Code.
            </span>
          </h3>

          <div className="space-y-4 font-jakarta text-sm sm:text-base text-[#9A9EA7] leading-relaxed">
            <p>
              Over the past <strong className="text-[#F4F3EF]">{MK_PROFILE.experienceYears}</strong>
              , I observed a recurring flaw in how digital products are built: design agencies
              produce visually striking slides that break in production, while traditional software
              shops write functional backends wrapped in forgettable, generic templates.
            </p>
            <p>
              Operating independently as <strong className="text-[#F4F3EF]">Freelancer MK</strong>,
              I eliminate that divide. I partner directly with founders, CTOs, and creative
              directors to architect products where uncommon display typography, fluid 60fps
              interaction physics, and deterministic TypeScript/Next.js systems engineering are
              crafted under one roof.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 border-t border-[#F4F3EF]/10">
            {[
              {
                icon: Type,
                title: 'Uncommon Typography',
                detail: 'Custom variable optical serifs & geometric brutalist hierarchies.',
              },
              {
                icon: Terminal,
                title: 'Full-Stack Rigor',
                detail: 'Strict TypeScript, Edge APIs, WebSockets & 100 Lighthouse.',
              },
              {
                icon: Globe,
                title: 'Global Async Sync',
                detail: 'Seamless collaboration across Zurich, NYC, London, SF & Tokyo.',
              },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.title}
                  className="p-4 rounded-2xl bg-[#0B0C0E] border border-[#F4F3EF]/10 space-y-2"
                >
                  <Icon className="w-5 h-5 text-[#E2FF32]" />
                  <div className="font-syne font-bold text-sm text-[#F4F3EF]">{item.title}</div>
                  <div className="font-jakarta text-xs text-[#9A9EA7]">{item.detail}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 5 Columns: Technical Stack Matrix & Career Ledger */}
        <div className="lg:col-span-5 rounded-3xl bg-[#13151A] border border-[#F4F3EF]/12 p-7 sm:p-9 space-y-6">
          <div className="font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32] flex items-center gap-2">
            <Code2 className="w-4 h-4" /> PRODUCTION STACK TELEMETRY
          </div>

          <div className="space-y-4">
            {[
              {
                group: 'FRONTEND & MOTION ARCHITECTURE',
                items: ['React 19', 'Next.js 15', 'TypeScript 5.8', 'Tailwind CSS v4', 'WebGL / GLSL', 'Framer Motion'],
              },
              {
                group: 'BACKEND, DATA & REALTIME',
                items: ['Node.js / Edge', 'PostgreSQL', 'Supabase', 'Prisma', 'WebSockets', 'Stripe API'],
              },
              {
                group: 'DESIGN SYSTEMS & TYPOGRAPHY',
                items: ['Figma Variables', 'Radix Primitives', 'Variable WebFonts', 'Storybook', 'WCAG AAA'],
              },
              {
                group: 'AI & AGENTIC WORKFLOWS',
                items: ['Vercel AI SDK', 'OpenAI / Claude', 'Streaming UI', 'Spatial Canvas'],
              },
            ].map((stackGroup) => (
              <div
                key={stackGroup.group}
                className="p-4 rounded-2xl bg-[#0B0C0E] border border-[#F4F3EF]/10 space-y-2.5"
              >
                <div className="font-mono-tech text-[10px] text-[#E2FF32]">
                  {stackGroup.group}
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {stackGroup.items.map((tech) => (
                    <span
                      key={tech}
                      className="px-2.5 py-1 rounded-md bg-[#13151A] border border-[#F4F3EF]/10 font-mono-tech text-[11px] text-[#F4F3EF]"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* INTERACTIVE FAQ ACCORDION */}
      <section className="space-y-8">
        <div className="border-b border-[#F4F3EF]/10 pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32] mb-2">
              OPERATIONAL CLARITY
            </div>
            <h3 className="font-syne font-extrabold text-2xl sm:text-4xl text-[#F4F3EF]">
              Frequently Asked{' '}
              <span className="font-editorial italic font-normal text-[#E2FF32]">
                Founder Questions
              </span>
            </h3>
          </div>
          <button
            onClick={() => onOpenBooking('Custom Question for Moin Uddin Khan')}
            className="px-5 py-3 rounded-full bg-[#E2FF32] text-[#0B0C0E] font-syne font-bold text-xs uppercase tracking-wider flex items-center gap-2 self-start sm:self-auto"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Ask MK Directly</span>
          </button>
        </div>

        <div className="space-y-3">
          {FAQS.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={faq.q}
                className={`rounded-2xl border transition-all ${
                  isOpen
                    ? 'bg-[#13151A] border-[#E2FF32]/50'
                    : 'bg-[#13151A]/60 border-[#F4F3EF]/10 hover:border-[#F4F3EF]/25'
                }`}
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono-tech text-xs text-[#E2FF32] font-bold">
                      0{idx + 1}
                    </span>
                    <span className="font-syne font-bold text-base sm:text-lg text-[#F4F3EF]">
                      {faq.q}
                    </span>
                  </div>
                  <ChevronDown
                    className={`w-5 h-5 text-[#E2FF32] shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-6 pb-6 pt-0 font-jakarta text-sm sm:text-base text-[#9A9EA7] leading-relaxed border-t border-[#F4F3EF]/10 mt-1 pt-4">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
