import React, { useState } from 'react';
import {
  FrontTextStyle,
  MK_PROFILE,
  PageId,
  PROJECTS,
  ProjectItem,
  SERVICES,
  FLASH_OFFERS,
  REVIEWS,
} from '../data/mkData';
import { UncommonHeadline } from '../components/UncommonHeadline';
import { ProjectVisualCanvas } from '../components/ProjectVisualCanvas';
import {
  ArrowRight,
  ArrowUpRight,
  Compass,
  Flame,
  Star,
  Terminal,
  Type,
} from 'lucide-react';

interface HomePageProps {
  frontTextStyle: FrontTextStyle;
  onChangeFrontTextStyle: (style: FrontTextStyle) => void;
  onNavigate: (page: PageId) => void;
  onSelectProject: (project: ProjectItem) => void;
  onOpenBooking: (presetContext?: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  frontTextStyle,
  onChangeFrontTextStyle,
  onNavigate,
  onSelectProject,
  onOpenBooking,
}) => {
  const [personaLens, setPersonaLens] = useState<'architect' | 'director'>('director');

  const featuredProjects = PROJECTS.slice(0, 4);

  return (
    <div className="space-y-24 pb-20">
      {/* HERO SECTION: 12-Column Asymmetric Architectural Grid */}
      <section className="relative pt-8 sm:pt-14 px-4 sm:px-8 max-w-[1440px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-start">
          {/* Left 7 Columns: Monumental Uncommon Front-Text Stack */}
          <div className="lg:col-span-7 space-y-7">
            {/* Top Status & Coordinates Pill */}
            <div className="flex flex-wrap items-center gap-2.5">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#13151A] border border-[#10B981]/35">
                <span className="w-2 h-2 rounded-full bg-[#10B981] pulse-volt" />
                <span className="font-mono-tech text-[11px] uppercase tracking-[0.15em] text-[#10B981] font-bold">
                  {MK_PROFILE.availability}
                </span>
              </div>
              <span className="font-mono-tech text-[11px] uppercase tracking-[0.14em] text-[#9A9EA7] px-3 py-1.5 rounded-full bg-[#13151A] border border-[#F4F3EF]/10">
                IDENTITY // MOIN UDDIN KHAN (FREELANCER MK)
              </span>
            </div>

            {/* Dynamic Monumental Display Headline */}
            <UncommonHeadline
              primaryText="MOIN UDDIN KHAN"
              editorialAccent="Crafting Uncommon"
              secondaryText="DIGITAL MONOPOLIES."
              frontTextStyle={frontTextStyle}
              size="hero"
            />

            {/* Interactive Uncommon Front-Text Live Bar */}
            <div className="p-3.5 rounded-2xl bg-[#13151A]/90 border border-[#F4F3EF]/12 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Type className="w-4 h-4 text-[#E2FF32]" />
                <span className="font-mono-tech text-[11px] uppercase tracking-wider text-[#F4F3EF]">
                  LIVE FRONT-TEXT SPECIMEN:
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-1.5">
                {(
                  [
                    { id: 'hybrid', label: '01 Hybrid Kinetic' },
                    { id: 'brutalist', label: '02 Brutalist Syne' },
                    { id: 'couture', label: '03 Couture Serif' },
                    { id: 'outlined', label: '04 Wireframe Stroke' },
                  ] as { id: FrontTextStyle; label: string }[]
                ).map((mode) => (
                  <button
                    key={mode.id}
                    onClick={() => onChangeFrontTextStyle(mode.id)}
                    className={`px-3 py-1 rounded-lg font-mono-tech text-[11px] transition-all border ${
                      frontTextStyle === mode.id
                        ? 'bg-[#E2FF32] text-[#0B0C0E] border-[#E2FF32] font-bold'
                        : 'bg-[#0B0C0E] text-[#9A9EA7] border-[#F4F3EF]/10 hover:text-[#F4F3EF]'
                    }`}
                  >
                    {mode.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Editorial Lead Paragraph */}
            <p className="font-jakarta text-base sm:text-xl text-[#9A9EA7] leading-relaxed max-w-[64ch]">
              Independent Principal Creative Technologist & Full-Stack Product Architect known as{' '}
              <span className="text-[#F4F3EF] font-semibold underline decoration-[#E2FF32] decoration-2 underline-offset-4">
                Freelancer MK
              </span>
              . I fuse avant-garde editorial typography with sub-second{' '}
              <span className="text-[#F4F3EF]">Next.js, TypeScript & WebGL</span> engineering for
              venture-backed founders and global category leaders.
            </p>

            {/* Primary & Secondary Action Cluster */}
            <div className="flex flex-wrap items-center gap-4 pt-1">
              <button
                onClick={() => onNavigate('work')}
                className="px-7 py-4 rounded-full bg-[#E2FF32] hover:bg-[#ebff66] text-[#0B0C0E] font-syne font-extrabold text-sm uppercase tracking-wider flex items-center gap-2.5 shadow-[0_0_32px_rgba(226,255,50,0.28)] transition-all hover:scale-[1.02]"
              >
                <span>Explore Selected Works (06)</span>
                <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
              </button>

              <button
                onClick={() => onNavigate('offers')}
                className="px-6 py-4 rounded-full bg-[#13151A] hover:bg-[#1b1e26] text-[#F4F3EF] border border-[#F4F3EF]/15 hover:border-[#FF4D2D] font-syne font-bold text-sm flex items-center gap-2 transition-all"
              >
                <Flame className="w-4 h-4 text-[#FF4D2D]" />
                <span>View Sprint Offers & Deals</span>
              </button>
            </div>

            {/* Key Quantitative Proof Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-[#F4F3EF]/10">
              {[
                { val: MK_PROFILE.projectsShipped, label: 'Flagships Shipped' },
                { val: MK_PROFILE.valueCreated, label: 'Client Value Created' },
                { val: '4.98 / 5.0', label: 'Verified Review Score' },
                { val: '100 / 100', label: 'Lighthouse Standard' },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="p-3.5 rounded-2xl bg-[#13151A]/60 border border-[#F4F3EF]/10"
                >
                  <div className="font-syne font-extrabold text-2xl sm:text-3xl text-[#F4F3EF]">
                    {stat.val}
                  </div>
                  <div className="font-mono-tech text-[10px] uppercase tracking-wider text-[#9A9EA7] mt-1">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right 5 Columns: Interactive MK Architectural Identity & Dual-Lens Inspect Card */}
          <div className="lg:col-span-5">
            <div className="rounded-3xl bg-[#13151A] border border-[#F4F3EF]/15 p-6 sm:p-7 space-y-6 relative overflow-hidden shadow-2xl">
              {/* Top Lens Switcher */}
              <div className="flex items-center justify-between gap-2 pb-4 border-b border-[#F4F3EF]/10">
                <div className="font-mono-tech text-[11px] uppercase tracking-widest text-[#E2FF32]">
                  MK // DUAL-DISCIPLINE DOSSIER
                </div>
                <div className="flex items-center p-1 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/10">
                  <button
                    onClick={() => setPersonaLens('director')}
                    className={`px-2.5 py-1 rounded-lg font-mono-tech text-[10px] uppercase transition-all ${
                      personaLens === 'director'
                        ? 'bg-[#E2FF32] text-[#0B0C0E] font-bold'
                        : 'text-[#9A9EA7] hover:text-[#F4F3EF]'
                    }`}
                  >
                    Art Director
                  </button>
                  <button
                    onClick={() => setPersonaLens('architect')}
                    className={`px-2.5 py-1 rounded-lg font-mono-tech text-[10px] uppercase transition-all ${
                      personaLens === 'architect'
                        ? 'bg-[#E2FF32] text-[#0B0C0E] font-bold'
                        : 'text-[#9A9EA7] hover:text-[#F4F3EF]'
                    }`}
                  >
                    Full-Stack Eng
                  </button>
                </div>
              </div>

              {/* Monogram & Sculptural Identity Visual */}
              <div className="p-5 rounded-2xl bg-[#0B0C0E] border border-[#F4F3EF]/10 relative overflow-hidden">
                <div className="absolute -right-6 -bottom-8 font-syne font-extrabold text-[120px] leading-none text-stroke-bone opacity-30 pointer-events-none select-none">
                  MK
                </div>
                <div className="relative z-10 flex items-start justify-between gap-4">
                  <div className="space-y-1">
                    <span className="inline-block px-2.5 py-0.5 rounded bg-[#E2FF32]/15 text-[#E2FF32] font-mono-tech text-[10px] font-bold">
                      PRINCIPAL CREATIVE TECHNOLOGIST
                    </span>
                    <h2 className="font-syne font-extrabold text-2xl text-[#F4F3EF]">
                      Moin Uddin Khan
                    </h2>
                    <p className="font-editorial italic text-xl text-[#9A9EA7]">
                      “Where uncommon editorial typography meets deterministic systems code.”
                    </p>
                  </div>
                  <div className="w-14 h-14 rounded-2xl bg-[#E2FF32] text-[#0B0C0E] font-syne font-extrabold text-xl flex items-center justify-center shrink-0 shadow-lg">
                    MK
                  </div>
                </div>

                {/* Dynamic Lens Output */}
                <div className="relative z-10 mt-5 pt-4 border-t border-[#F4F3EF]/10">
                  {personaLens === 'director' ? (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between font-mono-tech text-xs text-[#E2FF32]">
                        <span className="flex items-center gap-1.5">
                          <Compass className="w-3.5 h-3.5" /> VISUAL & TYPOGRAPHIC DIRECTION
                        </span>
                        <span>AWWWARDS CRAFT</span>
                      </div>
                      <p className="font-jakarta text-xs sm:text-sm text-[#F4F3EF]/90 leading-relaxed">
                        Specializing in uncommon front-text hierarchies (Syne, Instrument Serif,
                        Fraunces, Swiss Monospace), micro-interaction physics, and high-converting
                        scrollytelling architectures.
                      </p>
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {[
                          'Kinetic Typography',
                          'Design Systems',
                          'Figma Variables',
                          'WebGL Shaders',
                          'Conversion UX',
                        ].map((tag) => (
                          <span
                            key={tag}
                            className="px-2.5 py-1 rounded-md bg-[#13151A] border border-[#F4F3EF]/10 font-mono-tech text-[10px] text-[#F4F3EF]"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between font-mono-tech text-xs text-[#38BDF8]">
                        <span className="flex items-center gap-1.5">
                          <Terminal className="w-3.5 h-3.5" /> FULL-STACK SYSTEMS ARCHITECTURE
                        </span>
                        <span>SUB-SECOND SLA</span>
                      </div>
                      <p className="font-jakarta text-xs sm:text-sm text-[#F4F3EF]/90 leading-relaxed">
                        Production-hardened React 19, Next.js 15 App Router, strict TypeScript,
                        WebSockets, PostgreSQL/Supabase, Stripe pipelines, and AI agentic streaming.
                      </p>
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {[
                          'Next.js 15 / React 19',
                          'TypeScript Strict',
                          'PostgreSQL & Edge',
                          'WebSockets / WASM',
                          'Vercel AI SDK',
                        ].map((tag) => (
                          <span
                            key={tag}
                            className="px-2.5 py-1 rounded-md bg-[#13151A] border border-[#38BDF8]/30 font-mono-tech text-[10px] text-[#38BDF8]"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Featured Flash Offer Mini-Card Inside Hero */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-[#FF4D2D]/15 via-[#181B22] to-[#E2FF32]/15 border border-[#FF4D2D]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-[#FF4D2D] text-[#0B0C0E] font-mono-tech text-[10px] font-bold uppercase">
                      FLASH OFFER // 2 SLOTS
                    </span>
                    <span className="font-mono-tech text-xs line-through text-[#9A9EA7]">
                      $1,600
                    </span>
                    <span className="font-mono-tech text-xs font-bold text-[#E2FF32]">$950</span>
                  </div>
                  <div className="font-syne font-bold text-sm text-[#F4F3EF]">
                    72-Hour Hero & Uncommon Front-Text Makeover
                  </div>
                </div>
                <button
                  onClick={() =>
                    onOpenBooking('Flash Offer: 72-Hour Hero & Uncommon Front-Text Makeover ($950)')
                  }
                  className="px-4 py-2.5 rounded-xl bg-[#F4F3EF] hover:bg-[#E2FF32] text-[#0B0C0E] font-mono-tech text-xs font-bold uppercase tracking-wider shrink-0 transition-colors"
                >
                  Claim Slot →
                </button>
              </div>

              {/* Bottom Telemetry Footer */}
              <div className="flex items-center justify-between font-mono-tech text-[11px] text-[#9A9EA7] pt-1">
                <span>RESPONSE SLA: &lt; 3.5 HOURS</span>
                <button
                  onClick={() => onNavigate('studio')}
                  className="text-[#E2FF32] hover:underline"
                >
                  OPEN TYPE LAB & BIO →
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* UNCOMMON KINETIC TYPOGRAPHY MARQUEE STRIP */}
      <section className="border-y border-[#F4F3EF]/12 bg-[#0E1015] py-5 overflow-hidden">
        <div className="animate-marquee flex items-center gap-10">
          {[1, 2].map((loop) => (
            <div key={loop} className="flex items-center gap-10 shrink-0">
              <span className="font-syne font-extrabold text-2xl sm:text-4xl uppercase tracking-tight text-[#F4F3EF]">
                MOIN UDDIN KHAN
              </span>
              <span className="font-mono-tech text-xs px-3 py-1 rounded-full bg-[#E2FF32] text-[#0B0C0E] font-bold">
                FREELANCER MK // 2026
              </span>
              <span className="font-editorial italic text-3xl sm:text-4xl text-[#E2FF32]">
                uncommon front-text architecture
              </span>
              <span className="font-syne font-extrabold text-2xl sm:text-4xl uppercase text-stroke-bone">
                SUB-SECOND FULL-STACK PRODUCTS
              </span>
              <span className="font-mono-tech text-xs px-3 py-1 rounded-full border border-[#FF4D2D] text-[#FF4D2D]">
                100 LIGHTHOUSE GUARANTEED
              </span>
              <span className="font-fraunces italic text-2xl sm:text-3xl text-[#F4F3EF]">
                Bespoke UI/UX & Conversion Engineering
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* SELECTED PORTFOLIO SHOWCASE (PREVIEW OF PAGE 02) */}
      <section className="px-4 sm:px-8 max-w-[1440px] mx-auto space-y-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-[#F4F3EF]/10 pb-8">
          <UncommonHeadline
            kicker="01 // SELECTED ARCHITECTURAL ARCHIVE"
            primaryText="PROVEN WORKS"
            editorialAccent="engineered for"
            secondaryText="MARKET DOMINANCE"
            frontTextStyle={frontTextStyle}
            size="section"
          />
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <p className="font-mono-tech text-xs text-[#9A9EA7] max-w-xs">
              Click any project card to inspect before/after telemetry, stack & typographic notes.
            </p>
            <button
              onClick={() => onNavigate('work')}
              className="px-5 py-3 rounded-full bg-[#13151A] hover:bg-[#E2FF32] text-[#F4F3EF] hover:text-[#0B0C0E] border border-[#F4F3EF]/15 font-mono-tech text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all self-start sm:self-auto"
            >
              <span>Full Archive (06)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 2-Column Editorial Split Project Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {featuredProjects.map((project) => (
            <article
              key={project.id}
              onClick={() => onSelectProject(project)}
              className="group cursor-pointer rounded-3xl bg-[#13151A] border border-[#F4F3EF]/10 hover:border-[#E2FF32]/60 p-6 sm:p-7 flex flex-col justify-between gap-6 transition-all duration-300 hover:-translate-y-1 shadow-xl"
            >
              {/* Top Meta Row */}
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono-tech text-xs font-bold text-[#E2FF32]">
                      [{project.index}]
                    </span>
                    <span className="font-mono-tech text-xs uppercase tracking-wider px-2.5 py-1 rounded-full bg-[#0B0C0E] border border-[#F4F3EF]/10 text-[#F4F3EF]">
                      {project.category}
                    </span>
                    <span className="font-mono-tech text-xs text-[#9A9EA7]">
                      {project.client} • {project.year}
                    </span>
                  </div>
                  <span className="font-mono-tech text-xs px-2.5 py-1 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30 font-bold">
                    {project.metricBadge}
                  </span>
                </div>

                {/* Interactive Visual Canvas */}
                <div className="h-[250px]">
                  <ProjectVisualCanvas project={project} />
                </div>
              </div>

              {/* Project Title, Typography Note & Stack */}
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-syne font-extrabold text-2xl sm:text-3xl text-[#F4F3EF] group-hover:text-[#E2FF32] transition-colors">
                      {project.title}
                    </h3>
                    <ArrowUpRight className="w-6 h-6 text-[#9A9EA7] group-hover:text-[#E2FF32] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                  </div>
                  <p className="font-editorial italic text-xl sm:text-2xl text-[#9A9EA7] mt-0.5">
                    {project.subtitle}
                  </p>
                </div>

                <p className="font-jakarta text-sm text-[#9A9EA7] line-clamp-2 leading-relaxed">
                  {project.summary}
                </p>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-[#F4F3EF]/10">
                  <div className="flex flex-wrap gap-1.5">
                    {project.stack.slice(0, 4).map((t) => (
                      <span
                        key={t}
                        className="font-mono-tech text-[10px] px-2.5 py-1 rounded bg-[#0B0C0E] text-[#9A9EA7] border border-[#F4F3EF]/10"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                  <span className="font-mono-tech text-[11px] text-[#E2FF32] font-bold">
                    OPEN DOSSIER →
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* FREELANCE SERVICES SNAPSHOT (PREVIEW OF PAGE 03) */}
      <section className="px-4 sm:px-8 max-w-[1440px] mx-auto space-y-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-[#F4F3EF]/10 pb-8">
          <UncommonHeadline
            kicker="02 // BESPOKE FREELANCE CAPABILITIES"
            primaryText="DISCIPLINES OF"
            editorialAccent="high-craft"
            secondaryText="EXECUTION"
            frontTextStyle={frontTextStyle}
            size="section"
          />
          <button
            onClick={() => onNavigate('services')}
            className="px-5 py-3 rounded-full bg-[#13151A] hover:bg-[#E2FF32] text-[#F4F3EF] hover:text-[#0B0C0E] border border-[#F4F3EF]/15 font-mono-tech text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all self-start md:self-auto"
          >
            <span>Interactive Cost Estimator</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {SERVICES.map((srv) => (
            <div
              key={srv.id}
              onClick={() => onNavigate('services')}
              className="cursor-pointer group rounded-3xl bg-[#13151A] border border-[#F4F3EF]/10 hover:border-[#E2FF32] p-6 flex flex-col justify-between gap-6 transition-all"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="font-mono-tech text-xs text-[#E2FF32] font-bold">
                    {srv.code}
                  </span>
                  <span className="font-mono-tech text-[11px] px-2.5 py-0.5 rounded-full bg-[#0B0C0E] text-[#9A9EA7] border border-[#F4F3EF]/10">
                    {srv.turnaround}
                  </span>
                </div>
                <h3 className="font-syne font-extrabold text-xl text-[#F4F3EF] group-hover:text-[#E2FF32] transition-colors">
                  {srv.title}
                </h3>
                <p className="font-editorial italic text-lg text-[#E2FF32]">
                  {srv.editorialTag}
                </p>
                <p className="font-jakarta text-xs text-[#9A9EA7] leading-relaxed">
                  {srv.shortDesc}
                </p>
              </div>

              <div className="pt-4 border-t border-[#F4F3EF]/10 space-y-3">
                <div className="flex items-baseline justify-between">
                  <span className="font-mono-tech text-[10px] uppercase text-[#9A9EA7]">
                    STARTING INVESTMENT
                  </span>
                  <span className="font-syne font-extrabold text-lg text-[#F4F3EF]">
                    ${srv.startingAtUSD.toLocaleString()}
                  </span>
                </div>
                <div className="font-mono-tech text-[11px] text-[#10B981] flex items-center justify-between">
                  <span>{srv.outcomeMetric}</span>
                  <ArrowUpRight className="w-4 h-4 text-[#E2FF32]" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* SPECIAL OFFERS & REVIEWS DUAL HIGHLIGHT BANNER */}
      <section className="px-4 sm:px-8 max-w-[1440px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left 7 Columns: Special Offers Preview */}
          <div className="lg:col-span-7 rounded-3xl bg-gradient-to-br from-[#161922] via-[#13151A] to-[#1d1716] border border-[#E2FF32]/35 p-7 sm:p-9 flex flex-col justify-between gap-6">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FF4D2D]/20 border border-[#FF4D2D]/40 font-mono-tech text-xs text-[#FF4D2D] font-bold">
                <Flame className="w-3.5 h-3.5" /> LIMITED Q2/Q3 PRODUCTIZED OFFERS
              </div>
              <h3 className="font-syne font-extrabold text-2xl sm:text-4xl text-[#F4F3EF] tracking-tight">
                Skip the 6-Month Agency Bloated Retainer.{' '}
                <span className="font-editorial italic font-normal text-[#E2FF32]">
                  Ship in Days.
                </span>
              </h3>
              <p className="font-jakarta text-sm sm:text-base text-[#9A9EA7] leading-relaxed">
                Choose from fixed-scope productized sprints—including the popular{' '}
                <strong className="text-[#F4F3EF]">72-Hour Hero & Uncommon Font Makeover</strong>,{' '}
                <strong className="text-[#F4F3EF]">5-Day Figma-to-React Express</strong>, or full{' '}
                <strong className="text-[#F4F3EF]">4-Week MVP Launchpad Sprints</strong>.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {FLASH_OFFERS.slice(0, 2).map((offer) => (
                <div
                  key={offer.id}
                  className="p-4 rounded-2xl bg-[#0B0C0E]/90 border border-[#F4F3EF]/10 space-y-2"
                >
                  <div className="flex items-center justify-between font-mono-tech text-[10px]">
                    <span className="text-[#E2FF32]">{offer.discountBadge}</span>
                    <span className="text-[#9A9EA7]">{offer.turnaround}</span>
                  </div>
                  <div className="font-syne font-bold text-sm text-[#F4F3EF]">{offer.title}</div>
                  <div className="flex items-baseline gap-2">
                    <span className="font-syne font-extrabold text-xl text-[#E2FF32]">
                      ${offer.offerUSD}
                    </span>
                    <span className="font-mono-tech text-xs line-through text-[#5E626E]">
                      ${offer.originalUSD}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => onNavigate('offers')}
                className="px-6 py-3.5 rounded-full bg-[#E2FF32] text-[#0B0C0E] font-syne font-extrabold text-xs sm:text-sm uppercase tracking-wider flex items-center gap-2"
              >
                <span>Inspect All 7 Packages & Flash Offers</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() =>
                  onOpenBooking('Complimentary 20-Min Live Architecture & Typography Roast (FREE)')
                }
                className="px-5 py-3.5 rounded-full bg-[#0B0C0E] hover:bg-[#191C24] text-[#F4F3EF] border border-[#F4F3EF]/15 font-mono-tech text-xs"
              >
                Request Free 20-Min UX Roast
              </button>
            </div>
          </div>

          {/* Right 5 Columns: Client Review Ledger Highlight */}
          <div className="lg:col-span-5 rounded-3xl bg-[#13151A] border border-[#F4F3EF]/12 p-7 sm:p-9 flex flex-col justify-between gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32]">
                  VERIFIED CLIENT LEDGER
                </span>
                <div className="flex items-center gap-1 text-[#E2FF32]">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#E2FF32]" />
                  ))}
                  <span className="font-mono-tech text-xs font-bold ml-1 text-[#F4F3EF]">5.0</span>
                </div>
              </div>

              <blockquote className="font-editorial italic text-2xl sm:text-3xl text-[#F4F3EF] leading-snug">
                “{REVIEWS[0].headlineQuote}”
              </blockquote>

              <p className="font-jakarta text-xs sm:text-sm text-[#9A9EA7] leading-relaxed">
                {REVIEWS[0].fullReview}
              </p>
            </div>

            <div className="pt-4 border-t border-[#F4F3EF]/10 flex items-center justify-between">
              <div>
                <div className="font-syne font-bold text-sm text-[#F4F3EF]">
                  {REVIEWS[0].clientName}
                </div>
                <div className="font-mono-tech text-[11px] text-[#9A9EA7]">
                  {REVIEWS[0].role}, {REVIEWS[0].company} ({REVIEWS[0].location})
                </div>
              </div>
              <button
                onClick={() => onNavigate('reviews')}
                className="px-4 py-2 rounded-xl bg-[#0B0C0E] hover:bg-[#E2FF32] text-[#F4F3EF] hover:text-[#0B0C0E] border border-[#F4F3EF]/15 font-mono-tech text-xs transition-colors"
              >
                All Reviews (06) →
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
