import { useState, useEffect } from 'react';
import { FrontTextStyle, PageId, ProjectItem } from './data/mkData';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { CaseStudyDrawer } from './components/CaseStudyDrawer';
import { BookingDrawer } from './components/BookingDrawer';
import { HomePage } from './pages/HomePage';
import { WorkPage } from './pages/WorkPage';
import { ServicesPage } from './pages/ServicesPage';
import { OffersPage } from './pages/OffersPage';
import { ReviewsPage } from './pages/ReviewsPage';
import { StudioLabPage } from './pages/StudioLabPage';

const VALID_PAGES: PageId[] = ['home', 'work', 'services', 'offers', 'reviews', 'studio'];

export function App() {
  const [activePage, setActivePage] = useState<PageId>('home');
  const [frontTextStyle, setFrontTextStyle] = useState<FrontTextStyle>('hybrid');
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [bookingOpen, setBookingOpen] = useState<boolean>(false);
  const [bookingPreset, setBookingPreset] = useState<string | undefined>(undefined);

  // Sync with URL hash if present
  useEffect(() => {
    const syncFromHash = () => {
      const rawHash = window.location.hash.replace('#', '') as PageId;
      if (VALID_PAGES.includes(rawHash)) {
        setActivePage(rawHash);
      }
    };
    syncFromHash();
    window.addEventListener('hashchange', syncFromHash);
    return () => window.removeEventListener('hashchange', syncFromHash);
  }, []);

  const handleNavigate = (page: PageId) => {
    setActivePage(page);
    window.location.hash = page;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenBooking = (presetContext?: string) => {
    setBookingPreset(presetContext);
    setBookingOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#0B0C0E] text-[#F4F3EF] flex flex-col justify-between relative bg-radial-spotlight">
      {/* Subtle Architectural Grid Overlay */}
      <div className="fixed inset-0 bg-arch-grid pointer-events-none opacity-45 z-0" />

      {/* Top Sticky Multi-Page Navigation Bar */}
      <Navbar
        activePage={activePage}
        onNavigate={handleNavigate}
        frontTextStyle={frontTextStyle}
        onChangeFrontTextStyle={setFrontTextStyle}
        onOpenBooking={handleOpenBooking}
      />

      {/* Active Page Viewport */}
      <main className="relative z-10 flex-1">
        {activePage === 'home' && (
          <HomePage
            frontTextStyle={frontTextStyle}
            onChangeFrontTextStyle={setFrontTextStyle}
            onNavigate={handleNavigate}
            onSelectProject={(project) => setSelectedProject(project)}
            onOpenBooking={handleOpenBooking}
          />
        )}

        {activePage === 'work' && (
          <WorkPage
            frontTextStyle={frontTextStyle}
            onSelectProject={(project) => setSelectedProject(project)}
            onOpenBooking={handleOpenBooking}
          />
        )}

        {activePage === 'services' && (
          <ServicesPage
            frontTextStyle={frontTextStyle}
            onOpenBooking={handleOpenBooking}
          />
        )}

        {activePage === 'offers' && (
          <OffersPage
            frontTextStyle={frontTextStyle}
            onOpenBooking={handleOpenBooking}
          />
        )}

        {activePage === 'reviews' && (
          <ReviewsPage
            frontTextStyle={frontTextStyle}
            onOpenBooking={handleOpenBooking}
          />
        )}

        {activePage === 'studio' && (
          <StudioLabPage
            frontTextStyle={frontTextStyle}
            onChangeFrontTextStyle={setFrontTextStyle}
            onOpenBooking={handleOpenBooking}
          />
        )}
      </main>

      {/* Architectural Footer */}
      <div className="relative z-10">
        <Footer
          activePage={activePage}
          onNavigate={handleNavigate}
          frontTextStyle={frontTextStyle}
          onChangeFrontTextStyle={setFrontTextStyle}
          onOpenBooking={handleOpenBooking}
        />
      </div>

      {/* Deep-Dive Project Case Study Drawer */}
      <CaseStudyDrawer
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        onBookSimilar={(context) => handleOpenBooking(context)}
      />

      {/* Direct Booking & Offer Claiming Slide-Over Drawer */}
      <BookingDrawer
        isOpen={bookingOpen}
        onClose={() => setBookingOpen(false)}
        presetContext={bookingPreset}
      />
    </div>
  );
}

export default App;
