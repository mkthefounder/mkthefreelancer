import React from 'react';
import { ProjectItem } from '../data/mkData';
import { ProjectVisualCanvas } from './ProjectVisualCanvas';
import {
  ArrowUpRight,
  CheckCircle2,
  Cpu,
  Gauge,
  Layers,
  Quote,
  Sparkles,
  Type,
  X,
} from 'lucide-react';

interface CaseStudyDrawerProps {
  project: ProjectItem | null;
  onClose: () => void;
  onBookSimilar: (context: string) => void;
}

export const CaseStudyDrawer: React.FC<CaseStudyDrawerProps> = ({
  project,
  onClose,
  onBookSimilar,
}) => {
  if (!project) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#0B0C0E]/80 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Slide-over Panel */}
      <div className="relative z-10 w-full max-w-3xl bg-[#111318] border-l border-[#F4F3EF]/15 h-full overflow-y-auto flex flex-col justify-between shadow-2xl">
        {/* Sticky Top Header */}
        <div className="sticky top-0 z-20 backdrop-blur-xl bg-[#111318]/90 border-b border-[#F4F3EF]/10 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="font-mono-tech text-xs px-2.5 py-1 rounded bg-[#E2FF32]/15 text-[#E2FF32] border border-[#E2FF32]/30">
              CASE STUDY // {project.index}
            </span>
            <span className="font-mono-tech text-xs text-[#9A9EA7] hidden sm:inline">
              {project.client} • {project.location}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-[#191C24] hover:bg-[#E2FF32] text-[#F4F3EF] hover:text-[#0B0C0E] transition-colors"
            aria-label="Close Case Study"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 sm:p-8 space-y-8">
          {/* Title & Headline Metric */}
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono-tech text-[11px] uppercase tracking-widest px-3 py-1 rounded-full bg-[#F4F3EF]/10 text-[#F4F3EF]">
                {project.category}
              </span>
              <span className="font-mono-tech text-[11px] uppercase tracking-widest px-3 py-1 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">
                {project.metricBadge}
              </span>
              <span className="font-mono-tech text-[11px] text-[#9A9EA7]">
                Delivered in {project.duration} ({project.year})
              </span>
            </div>

            <h2 className="font-syne font-extrabold text-3xl sm:text-5xl tracking-tight text-[#F4F3EF] uppercase">
              {project.title}
            </h2>
            <p className="font-editorial italic text-2xl sm:text-3xl text-[#E2FF32]">
              {project.subtitle}
            </p>
            <p className="font-jakarta text-base text-[#9A9EA7] leading-relaxed pt-1">
              {project.summary}
            </p>
          </div>

          {/* Interactive Canvas Preview */}
          <div className="h-[290px]">
            <ProjectVisualCanvas project={project} interactive />
          </div>

          {/* Before vs After Benchmarks */}
          <div className="p-5 sm:p-6 rounded-2xl bg-[#0B0C0E] border border-[#F4F3EF]/10 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32]">
                <Gauge className="w-4 h-4" />
                <span>Verified Before / After Telemetry</span>
              </div>
              <span className="font-mono-tech text-xs text-[#9A9EA7]">
                {project.metricDetail}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {project.benchmarks.map((b) => (
                <div
                  key={b.label}
                  className="p-4 rounded-xl bg-[#13151A] border border-[#F4F3EF]/10 space-y-2"
                >
                  <div className="font-mono-tech text-[11px] text-[#9A9EA7]">{b.label}</div>
                  <div className="flex items-baseline justify-between">
                    <span className="font-mono-tech text-xs line-through text-[#5E626E]">
                      {b.before}
                    </span>
                    <span className="font-syne font-extrabold text-xl text-[#F4F3EF]">
                      {b.after}
                    </span>
                  </div>
                  <div className="inline-block px-2 py-0.5 rounded bg-[#E2FF32]/15 text-[#E2FF32] font-mono-tech text-[10px] font-bold">
                    {b.improvement}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Challenge & Architectural Solution */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 rounded-2xl bg-[#161920] border border-[#F4F3EF]/10 space-y-2">
              <div className="font-mono-tech text-xs uppercase tracking-widest text-[#FF4D2D] flex items-center gap-1.5">
                <Layers className="w-4 h-4" /> 01 // The Bottleneck
              </div>
              <p className="font-jakarta text-sm text-[#F4F3EF]/90 leading-relaxed">
                {project.challenge}
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-[#161920] border border-[#F4F3EF]/10 space-y-2">
              <div className="font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32] flex items-center gap-1.5">
                <Cpu className="w-4 h-4" /> 02 // MK Architecture
              </div>
              <p className="font-jakarta text-sm text-[#F4F3EF]/90 leading-relaxed">
                {project.architecture}
              </p>
            </div>
          </div>

          {/* Uncommon Typography Direction Note */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-[#E2FF32]/10 via-[#161920] to-[#FF4D2D]/10 border border-[#E2FF32]/30 space-y-2">
            <div className="font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32] flex items-center gap-1.5">
              <Type className="w-4 h-4" /> 03 // Uncommon Front-Text & Typographic System
            </div>
            <p className="font-jakarta text-sm text-[#F4F3EF] leading-relaxed">
              {project.typographyNote}
            </p>
          </div>

          {/* Deliverables & Tech Stack */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h4 className="font-mono-tech text-xs uppercase tracking-widest text-[#9A9EA7]">
                Shipped Deliverables
              </h4>
              <ul className="space-y-2">
                {project.deliverables.map((item) => (
                  <li
                    key={item}
                    className="flex items-start gap-2.5 font-jakarta text-sm text-[#F4F3EF]"
                  >
                    <CheckCircle2 className="w-4 h-4 text-[#E2FF32] shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-3">
              <h4 className="font-mono-tech text-xs uppercase tracking-widest text-[#9A9EA7]">
                Production Stack
              </h4>
              <div className="flex flex-wrap gap-2">
                {project.stack.map((tech) => (
                  <span
                    key={tech}
                    className="px-3 py-1.5 rounded-lg bg-[#0B0C0E] border border-[#F4F3EF]/12 font-mono-tech text-xs text-[#F4F3EF]"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Verified Client Quote */}
          <div className="p-6 rounded-2xl bg-[#0B0C0E] border border-[#F4F3EF]/12 relative">
            <Quote className="w-8 h-8 text-[#E2FF32]/20 absolute top-4 right-4" />
            <p className="font-editorial italic text-xl sm:text-2xl text-[#F4F3EF] leading-snug">
              “{project.clientQuote.text}”
            </p>
            <div className="mt-3 font-mono-tech text-xs text-[#E2FF32]">
              — {project.clientQuote.author},{' '}
              <span className="text-[#9A9EA7]">{project.clientQuote.role}</span>
            </div>
          </div>
        </div>

        {/* Sticky Bottom CTA Bar */}
        <div className="sticky bottom-0 z-20 backdrop-blur-xl bg-[#111318]/95 border-t border-[#F4F3EF]/10 px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            <div className="font-syne font-bold text-sm text-[#F4F3EF]">
              Want similar results for your product?
            </div>
            <div className="font-mono-tech text-[11px] text-[#9A9EA7]">
              Direct Principal Execution by Moin Uddin Khan
            </div>
          </div>
          <button
            onClick={() => {
              onClose();
              onBookSimilar(`Project Reference: ${project.title} (${project.category})`);
            }}
            className="w-full sm:w-auto px-5 py-3 rounded-full bg-[#E2FF32] hover:bg-[#ebff66] text-[#0B0C0E] font-syne font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all"
          >
            <Sparkles className="w-4 h-4" />
            <span>Commission Similar Project</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
