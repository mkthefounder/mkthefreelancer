import React, { useState } from 'react';
import { PageId, FrontTextStyle, MK_PROFILE } from '../data/mkData';
import { ArrowUpRight, Menu, Sparkles, Type, X } from 'lucide-react';

interface NavbarProps {
  activePage: PageId;
  onNavigate: (page: PageId) => void;
  frontTextStyle: FrontTextStyle;
  onChangeFrontTextStyle: (style: FrontTextStyle) => void;
  onOpenBooking: (presetContext?: string) => void;
}

const NAV_ITEMS: { id: PageId; index: string; label: string; badge?: string }[] = [
  { id: 'home', index: '01', label: 'Index' },
  { id: 'work', index: '02', label: 'Portfolio', badge: '06' },
  { id: 'services', index: '03', label: 'Services' },
  { id: 'offers', index: '04', label: 'Offers', badge: 'HOT' },
  { id: 'reviews', index: '05', label: 'Reviews', badge: '5.0★' },
  { id: 'studio', index: '06', label: 'Type Lab & Bio' },
];

const FONT_MODES: { id: FrontTextStyle; label: string; desc: string }[] = [
  { id: 'hybrid', label: '01 // Hybrid Kinetic', desc: 'Syne 800 + Instrument Serif Italic' },
  { id: 'brutalist', label: '02 // Swiss Brutalist', desc: 'Monumental Syne ExtraBold Uppercase' },
  { id: 'couture', label: '03 // Couture Editorial', desc: 'Fraunces + Instrument Serif Monograph' },
  { id: 'outlined', label: '04 // Wireframe Stroke', desc: 'Hollow Vector Outlined Display Type' },
];

export const Navbar: React.FC<NavbarProps> = ({
  activePage,
  onNavigate,
  frontTextStyle,
  onChangeFrontTextStyle,
  onOpenBooking,
}) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [fontMenuOpen, setFontMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-[#0B0C0E]/85 border-b border-[#F4F3EF]/10">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 h-20 flex items-center justify-between gap-3">
        {/* Brand Monogram & Identity */}
        <button
          onClick={() => onNavigate('home')}
          className="flex items-center gap-3 text-left group focus:outline-none"
        >
          <div className="w-11 h-11 rounded-xl bg-[#13151A] border border-[#F4F3EF]/15 group-hover:border-[#E2FF32] flex flex-col items-center justify-center transition-all duration-300 relative overflow-hidden">
            <span className="font-syne font-extrabold text-sm tracking-tighter text-[#F4F3EF] group-hover:text-[#E2FF32] transition-colors">
              MK
            </span>
            <span className="font-mono-tech text-[8px] text-[#9A9EA7] leading-none">
              //26
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-syne font-bold text-sm sm:text-base tracking-tight text-[#F4F3EF] group-hover:text-[#E2FF32] transition-colors">
                MOIN UDDIN KHAN
              </span>
              <span className="hidden xl:inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-[#10B981]/15 border border-[#10B981]/30 font-mono-tech text-[10px] text-[#10B981]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse" />
                AVAILABLE
              </span>
            </div>
            <div className="font-mono-tech text-[10px] tracking-[0.15em] uppercase text-[#9A9EA7]">
              [ FREELANCER MK // CREATIVE TECHNOLOGIST ]
            </div>
          </div>
        </button>

        {/* Center Multi-Page Navigation Pills */}
        <nav className="hidden lg:flex items-center p-1.5 rounded-full bg-[#13151A]/90 border border-[#F4F3EF]/10">
          {NAV_ITEMS.map((item) => {
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`relative px-3.5 py-2 rounded-full font-jakarta text-xs font-medium transition-all duration-250 flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-[#F4F3EF] text-[#0B0C0E] font-semibold shadow-sm'
                    : 'text-[#9A9EA7] hover:text-[#F4F3EF]'
                }`}
              >
                <span
                  className={`font-mono-tech text-[10px] ${
                    isActive ? 'text-[#0B0C0E]/70' : 'text-[#5E626E]'
                  }`}
                >
                  {item.index}
                </span>
                <span>{item.label}</span>
                {item.badge && (
                  <span
                    className={`font-mono-tech text-[9px] px-1.5 py-0.2 rounded-full ${
                      isActive
                        ? 'bg-[#0B0C0E] text-[#E2FF32]'
                        : item.badge === 'HOT'
                        ? 'bg-[#FF4D2D]/20 text-[#FF4D2D] border border-[#FF4D2D]/30'
                        : 'bg-[#F4F3EF]/10 text-[#F4F3EF]'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Controls: Uncommon Front-Text Mode Switcher + Primary CTA */}
        <div className="flex items-center gap-2.5">
          {/* Interactive Front-Text Switcher */}
          <div className="relative">
            <button
              onClick={() => setFontMenuOpen((prev) => !prev)}
              title="Switch Uncommon Display Typography Mode"
              className="hidden sm:flex items-center gap-2 px-3 py-2.5 rounded-full bg-[#13151A] hover:bg-[#1c1f26] border border-[#F4F3EF]/15 hover:border-[#E2FF32]/50 text-xs font-mono-tech text-[#F4F3EF] transition-all"
            >
              <Type className="w-3.5 h-3.5 text-[#E2FF32]" />
              <span className="hidden md:inline text-[11px] uppercase tracking-wider">
                TYPE: {frontTextStyle}
              </span>
            </button>

            {fontMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setFontMenuOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-72 rounded-2xl bg-[#13151A] border border-[#F4F3EF]/15 shadow-2xl p-3 z-50 space-y-1.5">
                  <div className="flex items-center justify-between px-2 py-1 border-b border-[#F4F3EF]/10">
                    <span className="font-mono-tech text-[10px] uppercase tracking-widest text-[#E2FF32] flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> Uncommon Front-Text Engine
                    </span>
                  </div>
                  {FONT_MODES.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => {
                        onChangeFrontTextStyle(m.id);
                        setFontMenuOpen(false);
                      }}
                      className={`w-full text-left p-2.5 rounded-xl transition-all border ${
                        frontTextStyle === m.id
                          ? 'bg-[#E2FF32]/12 border-[#E2FF32] text-[#F4F3EF]'
                          : 'bg-transparent border-transparent hover:bg-[#F4F3EF]/5 text-[#9A9EA7]'
                      }`}
                    >
                      <div className="font-mono-tech text-xs font-bold text-[#F4F3EF]">
                        {m.label}
                      </div>
                      <div className="font-jakarta text-[11px] text-[#9A9EA7] mt-0.5">
                        {m.desc}
                      </div>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Primary Initiate Project CTA */}
          <button
            onClick={() => onOpenBooking()}
            className="px-4 sm:px-5 py-2.5 rounded-full bg-[#E2FF32] hover:bg-[#ebff66] text-[#0B0C0E] font-syne font-bold text-xs sm:text-sm tracking-tight flex items-center gap-1.5 transition-all duration-200 shadow-[0_0_24px_rgba(226,255,50,0.25)] hover:scale-[1.02] active:scale-[0.98]"
          >
            <span>Hire MK</span>
            <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
          </button>

          {/* Mobile Hamburger Trigger */}
          <button
            onClick={() => setMobileOpen((prev) => !prev)}
            className="lg:hidden p-2.5 rounded-xl bg-[#13151A] border border-[#F4F3EF]/15 text-[#F4F3EF]"
            aria-label="Toggle Menu"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <div className="lg:hidden bg-[#0B0C0E] border-b border-[#F4F3EF]/15 px-4 pt-3 pb-6 space-y-4">
          <div className="grid grid-cols-2 gap-2">
            {NAV_ITEMS.map((item) => {
              const isActive = activePage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onNavigate(item.id);
                    setMobileOpen(false);
                  }}
                  className={`p-3 rounded-xl text-left border flex items-center justify-between ${
                    isActive
                      ? 'bg-[#E2FF32] text-[#0B0C0E] border-[#E2FF32] font-bold'
                      : 'bg-[#13151A] text-[#F4F3EF] border-[#F4F3EF]/10'
                  }`}
                >
                  <div>
                    <div
                      className={`font-mono-tech text-[10px] ${
                        isActive ? 'text-[#0B0C0E]/70' : 'text-[#9A9EA7]'
                      }`}
                    >
                      PAGE // {item.index}
                    </div>
                    <div className="font-syne text-sm font-bold mt-0.5">{item.label}</div>
                  </div>
                  {item.badge && (
                    <span className="font-mono-tech text-[10px] px-2 py-0.5 rounded-full bg-[#0B0C0E]/20">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Mobile Front-Text Selector */}
          <div className="p-3 rounded-xl bg-[#13151A] border border-[#F4F3EF]/10">
            <div className="font-mono-tech text-[10px] uppercase tracking-widest text-[#E2FF32] mb-2">
              SWITCH FRONT-TEXT TYPOGRAPHY STYLE:
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {FONT_MODES.map((m) => (
                <button
                  key={m.id}
                  onClick={() => onChangeFrontTextStyle(m.id)}
                  className={`px-2.5 py-1.5 rounded-lg font-mono-tech text-[10px] text-left border ${
                    frontTextStyle === m.id
                      ? 'border-[#E2FF32] bg-[#E2FF32]/15 text-[#E2FF32]'
                      : 'border-[#F4F3EF]/10 text-[#9A9EA7]'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between text-xs font-mono-tech text-[#10B981] px-1">
            <span>● {MK_PROFILE.availability}</span>
            <span>{MK_PROFILE.responseSLA}</span>
          </div>
        </div>
      )}
    </header>
  );
};
