import React from 'react';
import { FrontTextStyle, MK_PROFILE, PageId } from '../data/mkData';
import { ArrowUpRight, Sparkles, Type } from 'lucide-react';

interface FooterProps {
  activePage: PageId;
  onNavigate: (page: PageId) => void;
  frontTextStyle: FrontTextStyle;
  onChangeFrontTextStyle: (style: FrontTextStyle) => void;
  onOpenBooking: (presetContext?: string) => void;
}

export const Footer: React.FC<FooterProps> = ({
  activePage,
  onNavigate,
  frontTextStyle,
  onChangeFrontTextStyle,
  onOpenBooking,
}) => {
  return (
    <footer className="border-t border-[#F4F3EF]/12 bg-[#090A0D] relative overflow-hidden">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 pt-16 pb-12 space-y-14">
        {/* Top Monumental CTA Row */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 pb-12 border-b border-[#F4F3EF]/10">
          <div className="space-y-3 max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#10B981]/15 border border-[#10B981]/30 font-mono-tech text-xs text-[#10B981]">
              <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
              <span>{MK_PROFILE.availability}</span>
            </div>
            <h2 className="font-syne font-extrabold text-3xl sm:text-5xl lg:text-6xl uppercase tracking-tight text-[#F4F3EF] leading-[0.95]">
              HAVE AN AMBITIOUS{' '}
              <span className="font-editorial italic font-normal text-[#E2FF32] lowercase">
                product vision?
              </span>
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onOpenBooking()}
              className="px-7 py-4 rounded-full bg-[#E2FF32] hover:bg-[#ebff66] text-[#0B0C0E] font-syne font-extrabold text-sm uppercase tracking-wider flex items-center gap-2 shadow-[0_0_30px_rgba(226,255,50,0.28)] transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span>Initiate Project with MK</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('offers')}
              className="px-6 py-4 rounded-full bg-[#13151A] hover:bg-[#1c2029] text-[#F4F3EF] border border-[#F4F3EF]/15 font-mono-tech text-xs uppercase tracking-wider"
            >
              Inspect Flash Offers
            </button>
          </div>
        </div>

        {/* Middle Multi-Column Architectural Directory */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-5 space-y-3">
            <div className="font-syne font-extrabold text-xl text-[#F4F3EF]">
              MOIN UDDIN KHAN{' '}
              <span className="text-[#E2FF32] font-mono-tech text-xs font-bold">
                [FREELANCER MK]
              </span>
            </div>
            <p className="font-jakarta text-sm text-[#9A9EA7] max-w-sm leading-relaxed">
              Principal Creative Technologist, Full-Stack Product Architect & Uncommon Typography
              Director building high-yield web applications and design systems.
            </p>
            <div className="font-mono-tech text-xs text-[#F4F3EF] pt-1">
              DIRECT DISPATCH: <span className="text-[#E2FF32]">{MK_PROFILE.email}</span>
            </div>
          </div>

          <div className="lg:col-span-4 space-y-3">
            <div className="font-mono-tech text-xs uppercase tracking-widest text-[#9A9EA7]">
              MULTI-PAGE STUDIO ARCHITECTURE
            </div>
            <div className="grid grid-cols-2 gap-2 font-mono-tech text-xs">
              {(
                [
                  { id: 'home', label: '01 // Index' },
                  { id: 'work', label: '02 // Portfolio (06)' },
                  { id: 'services', label: '03 // Services' },
                  { id: 'offers', label: '04 // Offers & Deals' },
                  { id: 'reviews', label: '05 // Client Reviews' },
                  { id: 'studio', label: '06 // Type Lab & Bio' },
                ] as { id: PageId; label: string }[]
              ).map((item) => (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`text-left py-1 transition-colors ${
                    activePage === item.id
                      ? 'text-[#E2FF32] font-bold'
                      : 'text-[#9A9EA7] hover:text-[#F4F3EF]'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-3 space-y-3">
            <div className="font-mono-tech text-xs uppercase tracking-widest text-[#9A9EA7] flex items-center gap-1.5">
              <Type className="w-3.5 h-3.5 text-[#E2FF32]" /> FRONT-TEXT ENGINE
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {(['hybrid', 'brutalist', 'couture', 'outlined'] as FrontTextStyle[]).map(
                (style) => (
                  <button
                    key={style}
                    onClick={() => onChangeFrontTextStyle(style)}
                    className={`px-2.5 py-1.5 rounded-lg font-mono-tech text-[11px] uppercase border transition-all ${
                      frontTextStyle === style
                        ? 'bg-[#E2FF32] text-[#0B0C0E] border-[#E2FF32] font-bold'
                        : 'bg-[#13151A] text-[#9A9EA7] border-[#F4F3EF]/10 hover:text-[#F4F3EF]'
                    }`}
                  >
                    {style}
                  </button>
                )
              )}
            </div>
          </div>
        </div>

        {/* Sculptural Oversized Monogram Wordmark */}
        <div className="pt-4 border-t border-[#F4F3EF]/10 flex flex-col items-center">
          <div className="w-full text-center font-syne font-extrabold text-[clamp(2.2rem,8.2vw,7.8rem)] leading-[0.88] tracking-tighter uppercase text-stroke-bone select-none">
            FREELANCER MK // MOIN
          </div>
          <div className="w-full flex flex-col sm:flex-row items-center justify-between gap-2 pt-6 font-mono-tech text-[11px] text-[#5E626E]">
            <span>
              © {new Date().getFullYear()} MOIN UDDIN KHAN (FREELANCER MK). ALL RIGHTS RESERVED.
            </span>
            <span>ENGINEERED WITH UNCOMMON TYPOGRAPHY & SUB-SECOND PRECISION</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
