import React, { useState } from 'react';
import { ProjectItem } from '../data/mkData';
import { Terminal, Volume2, Zap } from 'lucide-react';

interface ProjectVisualCanvasProps {
  project: ProjectItem;
  interactive?: boolean;
}

export const ProjectVisualCanvas: React.FC<ProjectVisualCanvasProps> = ({
  project,
  interactive = false,
}) => {
  const [activeTick, setActiveTick] = useState(0);

  return (
    <div
      onClick={() => interactive && setActiveTick((prev) => (prev + 1) % 3)}
      className="relative w-full h-full min-h-[260px] bg-[#0D0F14] overflow-hidden select-none group border border-[#F4F3EF]/10 rounded-xl flex flex-col justify-between p-5"
      style={{
        backgroundImage: `radial-gradient(circle at 85% 15%, ${project.accentColor}18, transparent 60%), radial-gradient(circle at 15% 85%, ${project.secondaryColor}12, transparent 55%)`,
      }}
    >
      {/* Subtle architectural coordinate grid */}
      <div className="absolute inset-0 bg-arch-grid opacity-55 pointer-events-none" />

      {/* Top Window Telemetry Chrome */}
      <div className="relative z-10 flex items-center justify-between border-b border-[#F4F3EF]/10 pb-3">
        <div className="flex items-center gap-2">
          <span
            className="w-2.5 h-2.5 rounded-full"
            style={{ backgroundColor: project.accentColor }}
          />
          <span className="font-mono-tech text-[11px] tracking-[0.14em] uppercase text-[#F4F3EF]/80">
            MK // ARCHIVE_{project.index}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-mono-tech text-[10px] px-2 py-0.5 rounded bg-[#F4F3EF]/5 border border-[#F4F3EF]/10 text-[#9A9EA7]">
            {project.livePreviewStats.fps} FPS
          </span>
          <span
            className="font-mono-tech text-[10px] px-2 py-0.5 rounded font-bold"
            style={{
              backgroundColor: `${project.accentColor}20`,
              color: project.accentColor,
              border: `1px solid ${project.accentColor}45`,
            }}
          >
            LH {project.livePreviewStats.lighthouse}
          </span>
        </div>
      </div>

      {/* Bespoke Center Stage per Project ID */}
      <div className="relative z-10 my-auto py-5">
        {project.id === 'aetheria-quantum' && (
          <div className="space-y-3">
            <div className="flex items-baseline justify-between">
              <div>
                <div className="font-mono-tech text-[10px] text-[#9A9EA7] uppercase">
                  LIQUIDITY DEPTH // BTC-PERP-ZK
                </div>
                <div className="font-syne font-extrabold text-2xl sm:text-3xl text-[#F4F3EF] tracking-tight">
                  $94,820.<span className="text-[#E2FF32]">45</span>
                </div>
              </div>
              <div className="text-right font-mono-tech text-xs text-[#10B981]">
                ▲ +4.82% // 0.4ms TICK
              </div>
            </div>
            {/* Orderbook depth bars */}
            <div className="grid grid-cols-12 gap-1 items-end h-20 pt-2 px-2 bg-[#0B0C0E]/80 rounded-lg border border-[#F4F3EF]/10">
              {[42, 68, 55, 85, 95, 74, 45, 62, 88, 92, 78, 100].map((val, idx) => (
                <div key={idx} className="flex flex-col items-center gap-1 h-full justify-end">
                  <div
                    className="w-full rounded-t transition-all duration-500 group-hover:scale-y-105 origin-bottom"
                    style={{
                      height: `${((val + activeTick * 13) % 85) + 15}%`,
                      backgroundColor: idx < 6 ? '#10B981' : '#E2FF32',
                      opacity: idx < 6 ? 0.65 : 0.9,
                    }}
                  />
                </div>
              ))}
            </div>
            <div className="flex justify-between font-mono-tech text-[10px] text-[#9A9EA7]">
              <span>RING_BUFFER: ACTIVE</span>
              <span>THROUGHPUT: 12,400 MSG/S</span>
            </div>
          </div>
        )}

        {project.id === 'kinetix-atelier' && (
          <div className="relative flex flex-col items-center text-center py-2">
            <span className="font-mono-tech text-[10px] tracking-[0.22em] uppercase text-[#FF4D2D] mb-1">
              AW // 25 MONOGRAPH DROP
            </span>
            <div className="font-editorial italic text-4xl sm:text-5xl text-[#F4F3EF] leading-none tracking-tight">
              “Sculpted in Motion”
            </div>
            <div className="font-syne font-extrabold text-xl sm:text-2xl uppercase tracking-tighter text-stroke-bone mt-1">
              KINETIX PARIS — TOKYO
            </div>
            <div className="mt-4 flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-[#FF4D2D] text-[#0B0C0E] font-mono-tech text-[10px] font-bold uppercase">
                GLSL CLOTH SHADER
              </span>
              <span className="px-3 py-1 rounded-full bg-[#F4F3EF]/10 text-[#F4F3EF] font-mono-tech text-[10px]">
                0.18s ROUTE
              </span>
            </div>
          </div>
        )}

        {project.id === 'veridian-cloud-os' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between bg-[#0B0C0E]/90 px-3 py-2 rounded-lg border border-[#38BDF8]/30">
              <div className="flex items-center gap-2">
                <Terminal className="w-3.5 h-3.5 text-[#38BDF8]" />
                <span className="font-mono-tech text-xs text-[#F4F3EF]">
                  ⌘K &gt; deploy edge-cluster --region=global
                </span>
              </div>
              <span className="font-mono-tech text-[10px] text-[#E2FF32]">31ms</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[
                { region: 'FRA-01', load: '24%', status: 'OPTIMAL' },
                { region: 'SFO-04', load: '41%', status: 'OPTIMAL' },
                { region: 'NRT-02', load: '19%', status: 'OPTIMAL' },
              ].map((node) => (
                <div
                  key={node.region}
                  className="p-2.5 rounded-lg bg-[#13151A] border border-[#F4F3EF]/10 group-hover:border-[#38BDF8]/40 transition-colors"
                >
                  <div className="font-mono-tech text-[10px] text-[#9A9EA7]">{node.region}</div>
                  <div className="font-syne font-bold text-base text-[#F4F3EF] mt-0.5">
                    {node.load}
                  </div>
                  <div className="font-mono-tech text-[9px] text-[#38BDF8] mt-0.5">
                    ● {node.status}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {project.id === 'chronos-neural' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex-1 p-2.5 rounded-lg bg-[#13151A] border border-[#A855F7]/40">
                <div className="font-mono-tech text-[9px] text-[#A855F7]">AGENT_01 // PLANNER</div>
                <div className="font-jakarta text-xs font-semibold text-[#F4F3EF] mt-0.5">
                  Synthesize Schema
                </div>
              </div>
              <div className="font-mono-tech text-xs text-[#E2FF32]">──►</div>
              <div className="flex-1 p-2.5 rounded-lg bg-[#13151A] border border-[#E2FF32]/40">
                <div className="font-mono-tech text-[9px] text-[#E2FF32]">AGENT_02 // CODER</div>
                <div className="font-jakarta text-xs font-semibold text-[#F4F3EF] mt-0.5">
                  Stream AST Diff
                </div>
              </div>
            </div>
            <div className="p-2.5 rounded-lg bg-[#0B0C0E]/90 border border-[#F4F3EF]/10 font-mono-tech text-[11px] text-[#9A9EA7] flex items-center justify-between">
              <span>STREAMING: 148 TOKENS/SEC</span>
              <span className="text-[#E2FF32]">COST: $0.0014</span>
            </div>
          </div>
        )}

        {project.id === 'monolith-audio' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-syne font-extrabold text-sm tracking-wider uppercase text-[#E2FF32]">
                VCO-1 ANALOG MATRIX
              </span>
              <Volume2 className="w-4 h-4 text-[#FF4D2D]" />
            </div>
            <div className="grid grid-cols-4 gap-2 py-2">
              {['CUTOFF', 'RESONANCE', 'ENV MOD', 'DRIVE'].map((knob, i) => (
                <div
                  key={knob}
                  className="flex flex-col items-center p-2 rounded-lg bg-[#0B0C0E] border border-[#F4F3EF]/10"
                >
                  <div
                    className="w-8 h-8 rounded-full border-2 border-[#E2FF32] flex items-center justify-center relative transition-transform duration-500 group-hover:rotate-45"
                    style={{ transform: `rotate(${(i + 1) * 35}deg)` }}
                  >
                    <span className="w-0.5 h-3 bg-[#FF4D2D] -translate-y-1.5 rounded-full" />
                  </div>
                  <span className="font-mono-tech text-[9px] text-[#9A9EA7] mt-1.5">{knob}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {project.id === 'vanguard-ventures' && (
          <div className="space-y-2.5">
            <div className="font-editorial italic text-2xl sm:text-3xl text-[#F4F3EF]">
              “Backing Sovereign Compute & Deep Science.”
            </div>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <div className="p-2.5 rounded bg-[#0B0C0E]/90 border border-[#F59E0B]/30">
                <div className="font-mono-tech text-[9px] text-[#9A9EA7]">FUND II DEPLOYED</div>
                <div className="font-syne font-extrabold text-lg text-[#F59E0B]">$180.0M</div>
              </div>
              <div className="p-2.5 rounded bg-[#0B0C0E]/90 border border-[#E2FF32]/30">
                <div className="font-mono-tech text-[9px] text-[#9A9EA7]">FOUNDER OWNERSHIP</div>
                <div className="font-syne font-extrabold text-lg text-[#E2FF32]">82.4% SIM</div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Metric & Stack Strip */}
      <div className="relative z-10 flex items-center justify-between pt-3 border-t border-[#F4F3EF]/10">
        <div className="flex items-center gap-1.5">
          <Zap className="w-3.5 h-3.5" style={{ color: project.accentColor }} />
          <span className="font-mono-tech text-xs font-bold text-[#F4F3EF]">
            {project.metricBadge}
          </span>
        </div>
        <div className="font-mono-tech text-[11px] text-[#9A9EA7] group-hover:text-[#E2FF32] transition-colors">
          INSPECT CASE STUDY →
        </div>
      </div>
    </div>
  );
};
