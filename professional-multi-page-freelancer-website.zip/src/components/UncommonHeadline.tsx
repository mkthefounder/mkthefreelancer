import React from 'react';
import { FrontTextStyle } from '../data/mkData';

interface UncommonHeadlineProps {
  kicker?: string;
  primaryText: string;
  editorialAccent: string;
  secondaryText?: string;
  frontTextStyle: FrontTextStyle;
  size?: 'hero' | 'section' | 'banner';
}

export const UncommonHeadline: React.FC<UncommonHeadlineProps> = ({
  kicker,
  primaryText,
  editorialAccent,
  secondaryText,
  frontTextStyle,
  size = 'section',
}) => {
  const sizeClasses =
    size === 'hero'
      ? 'text-[clamp(2.55rem,6.6vw,5.85rem)] leading-[0.94]'
      : size === 'banner'
      ? 'text-[clamp(2.1rem,4.8vw,4.2rem)] leading-[0.96]'
      : 'text-[clamp(1.95rem,4.1vw,3.55rem)] leading-[0.98]';

  return (
    <div className="space-y-3">
      {kicker && (
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#13151A] border border-[#F4F3EF]/12">
          <span className="w-1.5 h-1.5 rounded-full bg-[#E2FF32]" />
          <span className="font-mono-tech text-[11px] uppercase tracking-[0.16em] text-[#9A9EA7]">
            {kicker}
          </span>
        </div>
      )}

      {frontTextStyle === 'hybrid' && (
        <h1 className={`${sizeClasses} tracking-[-0.035em] text-[#F4F3EF]`}>
          <span className="font-syne font-extrabold uppercase block sm:inline">
            {primaryText}{' '}
          </span>
          <span className="font-editorial italic font-normal text-[#E2FF32] tracking-[-0.01em] px-1">
            {editorialAccent}
          </span>
          {secondaryText && (
            <span className="font-syne font-extrabold uppercase block mt-1 text-stroke-bone">
              {secondaryText}
            </span>
          )}
        </h1>
      )}

      {frontTextStyle === 'brutalist' && (
        <h1
          className={`${sizeClasses} font-syne font-extrabold uppercase tracking-[-0.04em] text-[#F4F3EF]`}
        >
          <span>{primaryText} </span>
          <span className="bg-[#E2FF32] text-[#0B0C0E] px-2.5 py-0.5 inline-block transform -skew-x-6">
            {editorialAccent}
          </span>
          {secondaryText && <span className="block mt-1 text-[#9A9EA7]">{secondaryText}</span>}
        </h1>
      )}

      {frontTextStyle === 'couture' && (
        <h1 className={`${sizeClasses} font-fraunces font-semibold tracking-[-0.025em] text-[#F4F3EF]`}>
          <span>{primaryText} </span>
          <span className="font-editorial italic text-[#FF4D2D] underline decoration-[#E2FF32]/50 decoration-1 underline-offset-8">
            {editorialAccent}
          </span>
          {secondaryText && (
            <span className="font-editorial italic block mt-1 text-[#E2FF32]">
              — {secondaryText}
            </span>
          )}
        </h1>
      )}

      {frontTextStyle === 'outlined' && (
        <h1
          className={`${sizeClasses} font-syne font-extrabold uppercase tracking-[-0.035em]`}
        >
          <span className="text-stroke-strong">{primaryText} </span>
          <span className="text-[#E2FF32] font-editorial italic lowercase">
            {editorialAccent}
          </span>
          {secondaryText && (
            <span className="block mt-1 text-stroke-volt">{secondaryText}</span>
          )}
        </h1>
      )}
    </div>
  );
};
