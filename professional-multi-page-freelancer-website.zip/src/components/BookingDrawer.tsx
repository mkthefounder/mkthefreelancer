import React, { useState, useEffect } from 'react';
import { MK_PROFILE } from '../data/mkData';
import {
  ArrowRight,
  Calendar,
  Check,
  CheckCircle2,
  Clock,
  Copy,
  Mail,
  ShieldCheck,
  Sparkles,
  X,
} from 'lucide-react';

interface BookingDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  presetContext?: string;
}

const SCOPE_OPTIONS = [
  'Full-Stack Web / SaaS MVP',
  'Uncommon UI/UX & Typography',
  'Headless E-Commerce & WebGL',
  'AI-Native App / Agent Canvas',
  '72h Hero Makeover ($950)',
  'Principal Partner Retainer',
];

const BUDGET_PILLS = [
  '$950 – $2,000 (Flash / Audit)',
  '$2,500 – $4,500 (Sprint)',
  '$5,000 – $10,000 (Flagship)',
  '$10,000+ (Enterprise / Retainer)',
];

const TIMELINES = [
  'Immediate (Within 48h)',
  '2 – 4 Week Sprint',
  'Next Month Queue',
  'Ongoing Retainer',
];

export const BookingDrawer: React.FC<BookingDrawerProps> = ({
  isOpen,
  onClose,
  presetContext,
}) => {
  const [selectedScopes, setSelectedScopes] = useState<string[]>([
    'Full-Stack Web / SaaS MVP',
    'Uncommon UI/UX & Typography',
  ]);
  const [selectedBudget, setSelectedBudget] = useState<string>('$2,500 – $4,500 (Sprint)');
  const [selectedTimeline, setSelectedTimeline] = useState<string>('2 – 4 Week Sprint');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [companyUrl, setCompanyUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (presetContext) {
      setNotes(`Selected Reference / Offer: ${presetContext}\n\nProject Goals: `);
    }
  }, [presetContext]);

  if (!isOpen) return null;

  const toggleScope = (scope: string) => {
    setSelectedScopes((prev) =>
      prev.includes(scope) ? prev.filter((s) => s !== scope) : [...prev, scope]
    );
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(MK_PROFILE.email);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleReset = () => {
    setSubmitted(false);
    setName('');
    setEmail('');
    setCompanyUrl('');
    setNotes('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div
        className="fixed inset-0 bg-[#0B0C0E]/80 backdrop-blur-md"
        onClick={onClose}
      />

      <div className="relative z-10 w-full max-w-2xl bg-[#111318] border-l border-[#F4F3EF]/15 h-full overflow-y-auto flex flex-col justify-between shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 z-20 backdrop-blur-xl bg-[#111318]/90 border-b border-[#F4F3EF]/10 px-6 py-5 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
              <span className="font-mono-tech text-[11px] uppercase tracking-widest text-[#E2FF32]">
                DIRECT DISPATCH // MOIN UDDIN KHAN (MK)
              </span>
            </div>
            <h3 className="font-syne font-extrabold text-xl sm:text-2xl text-[#F4F3EF] mt-0.5">
              Initiate Project or Lock Offer Slot
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-[#1A1D24] hover:bg-[#E2FF32] text-[#F4F3EF] hover:text-[#0B0C0E] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form or Confirmation State */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Quick Direct Email Bar */}
          <div className="p-4 rounded-2xl bg-[#0B0C0E] border border-[#F4F3EF]/12 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#E2FF32]/15 border border-[#E2FF32]/30 flex items-center justify-center text-[#E2FF32]">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <div className="font-mono-tech text-[10px] uppercase tracking-wider text-[#9A9EA7]">
                  PREFER DIRECT EMAIL DISPATCH?
                </div>
                <div className="font-mono-tech text-xs sm:text-sm font-bold text-[#F4F3EF]">
                  {MK_PROFILE.email}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={handleCopyEmail}
              className="px-3.5 py-2 rounded-xl bg-[#161922] hover:bg-[#E2FF32] hover:text-[#0B0C0E] text-[#F4F3EF] border border-[#F4F3EF]/15 font-mono-tech text-xs flex items-center justify-center gap-1.5 transition-all"
            >
              {copiedEmail ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#10B981]" />
                  <span>COPIED ADDRESS</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>COPY EMAIL</span>
                </>
              )}
            </button>
          </div>

          {presetContext && !submitted && (
            <div className="p-3.5 rounded-xl bg-[#E2FF32]/10 border border-[#E2FF32]/35 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 font-mono-tech text-xs text-[#E2FF32]">
                <Sparkles className="w-4 h-4 shrink-0" />
                <span>LOCKED CONTEXT: {presetContext}</span>
              </div>
            </div>
          )}

          {submitted ? (
            <div className="p-8 rounded-3xl bg-[#0B0C0E] border border-[#E2FF32]/40 text-center space-y-5 my-6">
              <div className="w-16 h-16 rounded-2xl bg-[#E2FF32]/15 border border-[#E2FF32] flex items-center justify-center mx-auto text-[#E2FF32]">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <div className="space-y-2">
                <div className="font-mono-tech text-xs uppercase tracking-widest text-[#E2FF32]">
                  TRANSMISSION CONFIRMED // BRIEF #MK-{Math.floor(1000 + Math.random() * 9000)}
                </div>
                <h4 className="font-syne font-extrabold text-2xl sm:text-3xl text-[#F4F3EF]">
                  Moin Uddin Khan Has Received Your Brief
                </h4>
                <p className="font-jakarta text-sm text-[#9A9EA7] max-w-md mx-auto">
                  Expect a personalized architectural response and Loom walkthrough at{' '}
                  <span className="text-[#F4F3EF] font-semibold">{email || 'your inbox'}</span>{' '}
                  within 3.5 hours.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#13151A] border border-[#F4F3EF]/10 text-left font-mono-tech text-xs space-y-1.5 text-[#9A9EA7]">
                <div>
                  <span className="text-[#F4F3EF]">CLIENT:</span> {name || 'Founder'}
                </div>
                <div>
                  <span className="text-[#F4F3EF]">SCOPE:</span> {selectedScopes.join(' + ')}
                </div>
                <div>
                  <span className="text-[#F4F3EF]">ALLOCATION:</span> {selectedBudget}
                </div>
                <div>
                  <span className="text-[#F4F3EF]">TIMELINE:</span> {selectedTimeline}
                </div>
              </div>

              <button
                type="button"
                onClick={handleReset}
                className="px-6 py-3 rounded-full bg-[#E2FF32] text-[#0B0C0E] font-syne font-bold text-sm"
              >
                Return to MK Studio
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Step 1: Scope Selection */}
              <div className="space-y-2.5">
                <label className="block font-mono-tech text-xs uppercase tracking-wider text-[#9A9EA7]">
                  01 // SELECT ENGAGEMENT ARCHITECTURE (MULTIPLE ALLOWED)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {SCOPE_OPTIONS.map((scope) => {
                    const active = selectedScopes.includes(scope);
                    return (
                      <button
                        type="button"
                        key={scope}
                        onClick={() => toggleScope(scope)}
                        className={`p-3 rounded-xl text-left font-jakarta text-xs font-medium border transition-all flex items-center justify-between ${
                          active
                            ? 'bg-[#E2FF32]/15 border-[#E2FF32] text-[#F4F3EF]'
                            : 'bg-[#161920] border-[#F4F3EF]/10 text-[#9A9EA7] hover:text-[#F4F3EF]'
                        }`}
                      >
                        <span>{scope}</span>
                        {active && <Check className="w-3.5 h-3.5 text-[#E2FF32] shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Step 2: Budget Range */}
              <div className="space-y-2.5">
                <label className="block font-mono-tech text-xs uppercase tracking-wider text-[#9A9EA7]">
                  02 // INVESTMENT ALLOCATION (USD)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {BUDGET_PILLS.map((b) => {
                    const active = selectedBudget === b;
                    return (
                      <button
                        type="button"
                        key={b}
                        onClick={() => setSelectedBudget(b)}
                        className={`p-3 rounded-xl text-left font-mono-tech text-xs border transition-all ${
                          active
                            ? 'bg-[#F4F3EF] text-[#0B0C0E] border-[#F4F3EF] font-bold'
                            : 'bg-[#161920] border-[#F4F3EF]/10 text-[#9A9EA7] hover:text-[#F4F3EF]'
                        }`}
                      >
                        {b}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Step 3: Target Timeline */}
              <div className="space-y-2.5">
                <label className="block font-mono-tech text-xs uppercase tracking-wider text-[#9A9EA7]">
                  03 // TARGET LAUNCH CADENCE
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {TIMELINES.map((t) => {
                    const active = selectedTimeline === t;
                    return (
                      <button
                        type="button"
                        key={t}
                        onClick={() => setSelectedTimeline(t)}
                        className={`p-2.5 rounded-xl font-mono-tech text-xs border transition-all flex items-center gap-2 ${
                          active
                            ? 'border-[#E2FF32] bg-[#E2FF32]/15 text-[#E2FF32]'
                            : 'border-[#F4F3EF]/10 bg-[#161920] text-[#9A9EA7]'
                        }`}
                      >
                        <Calendar className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">{t}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Step 4: Contact Credentials */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1.5">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Alex Rivera"
                    className="w-full px-4 py-3 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 focus:border-[#E2FF32] focus:outline-none text-sm text-[#F4F3EF]"
                  />
                </div>
                <div>
                  <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1.5">
                    Work Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="alex@company.com"
                    className="w-full px-4 py-3 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 focus:border-[#E2FF32] focus:outline-none text-sm text-[#F4F3EF]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1.5">
                  Current Website / Figma Link (Optional)
                </label>
                <input
                  type="text"
                  value={companyUrl}
                  onChange={(e) => setCompanyUrl(e.target.value)}
                  placeholder="https://yourproduct.com"
                  className="w-full px-4 py-3 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 focus:border-[#E2FF32] focus:outline-none text-sm text-[#F4F3EF]"
                />
              </div>

              <div>
                <label className="block font-mono-tech text-[11px] uppercase text-[#9A9EA7] mb-1.5">
                  Project Context, Goals & Desired Outcome
                </label>
                <textarea
                  rows={4}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Tell Moin about your product vision, conversion targets, or the specific offer you want to lock..."
                  className="w-full px-4 py-3 rounded-xl bg-[#0B0C0E] border border-[#F4F3EF]/15 focus:border-[#E2FF32] focus:outline-none text-sm text-[#F4F3EF]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-full bg-[#E2FF32] hover:bg-[#ebff66] text-[#0B0C0E] font-syne font-extrabold text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_30px_rgba(226,255,50,0.3)] transition-all"
              >
                <span>Transmit Project Brief to MK</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>

        {/* Footer SLA Strip */}
        <div className="px-6 py-4 bg-[#0B0C0E] border-t border-[#F4F3EF]/10 flex flex-wrap items-center justify-between gap-2 font-mono-tech text-[11px] text-[#9A9EA7]">
          <span className="flex items-center gap-1.5 text-[#10B981]">
            <Clock className="w-3.5 h-3.5" /> Average Response: &lt; 3.5 Hours
          </span>
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-[#E2FF32]" /> 100% NDA & IP Protected
          </span>
        </div>
      </div>
    </div>
  );
};
